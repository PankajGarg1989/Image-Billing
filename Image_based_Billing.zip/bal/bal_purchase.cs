﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;

namespace bal
{
    public class bal_purchase
    {
        dal obj_dal = new dal();
        string spname = "purchase_sp";

        public DataSet loadItemsCmb(long userid)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "load_items_cmb"),
                                   new SqlParameter("@UserId", userid)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;
        }
        public long insertPurchase(entity_purchase obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_purchase"),
                                   new SqlParameter("@VendId", obj.vendor_id),
                                   new SqlParameter("@PurchaseTime",obj.purchase_time ),
                                   new SqlParameter("@TotalDiscount", obj.total_discount),
                                   new SqlParameter("@TotalAmount", obj.total_amount),
                                   new SqlParameter("@PayableAmount",obj.payable_amount ),
                                   new SqlParameter("@PaidAmount", obj.paid_amount),
                                   new SqlParameter("@PendingAmount",obj.pending_amount ),
                                   new SqlParameter("@InsertedBy", obj.insert_user )
                                   //new SqlParameter("@TVPItems", item_dt),
                                   //new SqlParameter("@TVPImg", img_dt )
                                   
                               };
            long purchaseid = Convert.ToInt64(obj_dal.get(p, spname).Tables[0].Rows[0]["purchaseid"]);
            return purchaseid;
        }

        public int insertItems(DataTable item_dt, long saleid, long user)
        {
            SqlParameter[] p ={
                                new SqlParameter("@Mode", "insert_items"),
                                new SqlParameter("@TVPInsertItems", item_dt),
                                new SqlParameter("@PurchaseId", saleid),
                                new SqlParameter("@InsertedBy", user)
                              };
            int check = obj_dal.set(p, spname);
            return check;
        }

        public int insertImages(DataTable img_dt, long saleid, long user)
        {
            SqlParameter[] p ={
                                new SqlParameter("@Mode", "insert_images"),
                                new SqlParameter("@TVPInsertImages", img_dt),
                                new SqlParameter("@PurchaseId", saleid),
                                new SqlParameter("@InsertedBy", user)
                              };
            int check = obj_dal.set(p, spname);
            return check;
        }

        public int undoPurchase(long purchaseid)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "undo_purchase"),
                                   new SqlParameter("@PurchaseId", purchaseid)
                               };
            int check = Convert.ToInt32(obj_dal.get(p, spname).Tables[0].Rows[0][0]);
            return check;
        }

        public int addItem(entity_purchase_detail obj_en_items, long purchaseid, long user)
        {
            SqlParameter[] p ={
                                new SqlParameter("@Mode", "insert_item"),
                                
                                new SqlParameter("@Name", obj_en_items.item_name),
                                new SqlParameter("@Quantity", obj_en_items.quantity),
                                new SqlParameter("@Price", obj_en_items.price_per_unit),
                                new SqlParameter("@Total", obj_en_items.total),
                                new SqlParameter("@DiscountP", obj_en_items.discount_percent),
                                new SqlParameter("@DiscountA", obj_en_items.discount_amount),
                                new SqlParameter("@Payable", obj_en_items.payable_amount),
                                new SqlParameter("@PurchaseId", purchaseid),
                                new SqlParameter("@InsertedBy", user)
                              };
            int check = obj_dal.set(p, spname);
            return check;
        }

        public int addImage(entity_purchase_files obj_en_files, long purchaseid, long user)
        {
            SqlParameter[] p ={
                                new SqlParameter("@Mode", "insert_item"),                      
                                new SqlParameter("@Name", obj_en_files.file_name),
                                new SqlParameter("@Total", obj_en_files.total),
                                new SqlParameter("@DiscountP", obj_en_files.discount_percent),
                                new SqlParameter("@DiscountA", obj_en_files.discount_amount),
                                new SqlParameter("@Payable", obj_en_files.payable_amount),
                                new SqlParameter("@PurchaseId", purchaseid),
                                new SqlParameter("@InsertedBy", user)
                              };
            int check = obj_dal.set(p, spname);
            return check;
        }
    }
}
