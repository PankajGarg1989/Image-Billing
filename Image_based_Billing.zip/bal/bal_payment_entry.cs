﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;


namespace bal
{
    public class bal_payment_entry
    {
        dal obj_dal = new dal();
        string spname = "payment_entry_sp";

        public DataSet getPending(Report obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","get_pending"),
                                   new SqlParameter("@CustId", obj.cust_id),                                  
                                   new SqlParameter("@FromDate", obj.from_date),
                                   new SqlParameter("@ToDate", obj.to_date),
                                   new SqlParameter("@UserId", obj.insert_user)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;

        }
        public int setBulkPayment(DataTable dt, long userid, DateTime pay_date)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_payments"),
                                   new SqlParameter("@TVPPayments",dt),
                                   new SqlParameter("@UserId", userid),
                                   new SqlParameter("@PayDate", pay_date)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }

        //obsolete
        public int setPayment(entity_payments obj) //was being used for single payment entry
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_new_payment"),
                                   new SqlParameter("@JobId",obj.sale_id),
                                   new SqlParameter("@Payment", obj.payment),
                                   new SqlParameter("@RefNo", obj.reference_no)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }
    }
}
