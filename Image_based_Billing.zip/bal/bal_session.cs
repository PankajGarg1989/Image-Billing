﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;

namespace bal
{
    public class bal_session
    {
        string spname = "session_sp";

        dal obj_dal = new dal();

        public DataTable readSessions()
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","read_sessions")
                               };
            DataTable dt = obj_dal.get(p, spname).Tables[0];
            return dt;

        }
        public int updateSessions(int session_id)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_sessions"),
                                   new SqlParameter("@SessionId", session_id )
                               };
            int  i = obj_dal.set(p, spname);
            return i;

        }

        public string getYear()
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "get_year")
                                   
                               };
            string s = obj_dal.get(p, spname).Tables[0].Rows[0][0].ToString().Substring(2,2);
            return s;
        }

    } 
}
