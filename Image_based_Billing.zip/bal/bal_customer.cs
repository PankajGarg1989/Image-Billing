﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;

namespace bal
{
    public class bal_customer
    {
        dal obj_dal = new dal();
        string spname = "customer_sp";

        public DataSet loadCustomer(long user)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","get_customer"),
                                   new SqlParameter("@UserId", user)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;

        }
        public int saveCustomer(entity_m_customer obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_customer"),
                                   new SqlParameter("@Company", obj.cust_company ),
                                   new SqlParameter("@Customer",obj.cust_name),
                                   new SqlParameter("@Address",obj.cust_address),
                                   new SqlParameter("@Phone",obj.cust_phone),
                                   new SqlParameter("@Mobile1", obj.cust_mobile1),
                                   new SqlParameter("@Mobile2", obj.cust_mobile2),
                                   new SqlParameter("@Email",obj.cust_email),
                                   new SqlParameter("@GSTNo",obj.cust_gst),
                                   new SqlParameter("@PANNo",obj.cust_pan),
                                   new SqlParameter("@AdhaarNo",obj.cust_aadhar),
                                   new SqlParameter("@InsertedBy",obj.insert_user)

                               };
            int check = obj_dal.set(p, spname);
            return check;
        }

       
        public int editCustomer(entity_m_customer obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_customer"),
                                   new SqlParameter("@Company", obj.cust_company ),
                                   new SqlParameter("@Customer",obj.cust_name),
                                   new SqlParameter("@Address",obj.cust_address),
                                   new SqlParameter("@Phone",obj.cust_phone),
                                   new SqlParameter("@Mobile1", obj.cust_mobile1),
                                   new SqlParameter("@Mobile2", obj.cust_mobile2),
                                   new SqlParameter("@Email",obj.cust_email),
                                   new SqlParameter("@GSTNo",obj.cust_gst),
                                   new SqlParameter("@PANNo",obj.cust_pan),
                                   new SqlParameter("@AdhaarNo",obj.cust_aadhar),
                                   new SqlParameter("@Customerid", obj.id),
                                   new SqlParameter("@ModifiedBy",obj.modify_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }

        public int changeCustomerStatus(entity_m_customer obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_customer_status"),
                                   new SqlParameter("@CustomerId", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }

        public int deleteCustomer(entity_m_customer obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "delete_customer"),
                                   new SqlParameter("@CustomerId", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }
    }
}
