﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;


namespace bal
{

    public class bal_tax
    {
        dal obj_dal = new dal();
        string spname = "tax_sp";

        public DataSet loadTax(long user)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","get_taxes"),
                                   new SqlParameter("@UserId", user)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;

        }
        public int saveTax(entity_m_tax obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_taxes"),
                                   new SqlParameter("@Name", obj.tax_name ),
                                   new SqlParameter("@Value",obj.tax_value),
                                   new SqlParameter("@InsertedBy",obj.insert_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }
        public int editTax(entity_m_tax obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_tax"),
                                   new SqlParameter("@Name", obj.tax_name ),
                                   new SqlParameter("@Value",obj.tax_value),
                                   new SqlParameter("@TaxId", obj.id),
                                   new SqlParameter("@ModifiedBy",obj.modify_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }

        public int deleteTax(entity_m_tax obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","delete_tax"),
                                   new SqlParameter("@TaxId", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }

       
    }
}
