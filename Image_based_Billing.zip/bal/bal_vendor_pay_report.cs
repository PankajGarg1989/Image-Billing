﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;

namespace bal
{
    public class bal_vendor_pay_report
    {
        string sp_name = "vendor_pay_report_sp";
        dal obj_dal = new dal();
        public DataSet getGridviewData(Report obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "get_gdv_data"),
                                   new SqlParameter("@VendId", obj.vend_id),                                  
                                   new SqlParameter("@FromDate", obj.from_date),
                                   new SqlParameter("@ToDate", obj.to_date),
                                   new SqlParameter("@UserId", obj.insert_user)
                               };
            DataSet ds = obj_dal.get(p, sp_name);
            return ds;
        }
    }
}
