﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;

namespace bal
{
    public class bal_vendor
    {
        dal obj_dal = new dal();
        string spname = "vendor_sp";

        public DataSet loadVendor(long user)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","get_vendor"),
                                   new SqlParameter("@UserId", user)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;

        }
        public int saveVendor(entity_m_vendor obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_vendor"),
                                   new SqlParameter("@Company", obj.vend_company ),
                                   new SqlParameter("@Vendor",obj.vend_name),
                                   new SqlParameter("@Address",obj.vend_address),
                                   new SqlParameter("@Phone",obj.vend_phone),
                                   new SqlParameter("@Mobile1",obj.vend_mobile1),
                                   new SqlParameter("@Mobile2", obj.vend_mobile2),
                                   new SqlParameter("@Email",obj.vend_email),
                                   new SqlParameter("@GSTNo",obj.vend_gst),
                                   new SqlParameter("@PANNo",obj.vend_pan),
                                   new SqlParameter("@AdhaarNo",obj.vend_aadhar),
                                   new SqlParameter("@InsertedBy",obj.insert_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }


        public int editVendor(entity_m_vendor obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_vendor"),
                                   new SqlParameter("@Company", obj.vend_company ),
                                   new SqlParameter("@Vendor",obj.vend_name),
                                   new SqlParameter("@Address",obj.vend_address),
                                   new SqlParameter("@Phone",obj.vend_phone),
                                   new SqlParameter("@Mobile1", obj.vend_mobile1),
                                   new SqlParameter("@Mobile2", obj.vend_mobile2),
                                   new SqlParameter("@Email",obj.vend_email),
                                   new SqlParameter("@GSTNo",obj.vend_gst),
                                   new SqlParameter("@PANNo",obj.vend_pan),
                                   new SqlParameter("@AdhaarNo",obj.vend_aadhar),
                                   new SqlParameter("@Vendorid", obj.id),
                                   new SqlParameter("@ModifiedBy",obj.modify_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }

        public int changeVendorStatus(entity_m_vendor obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_vendor_status"),
                                   new SqlParameter("@VendorId", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }

        public int deleteVendor(entity_m_vendor obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "delete_vendor"),
                                   new SqlParameter("@VendorId", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }
    }
}
