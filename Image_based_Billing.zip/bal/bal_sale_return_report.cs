﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using entity;
using dal_common;

namespace Image_Based_Billing
{
    public class bal_sale_return_report
    {
        string sp_name = "sale_return_report_sp";
        dal obj_dal = new dal();
        public DataSet getGridviewData(Report obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "get_gdv_data"),
                                   new SqlParameter("@CustId", obj.cust_id),                                  
                                   new SqlParameter("@FromDate", obj.from_date),
                                   new SqlParameter("@ToDate", obj.to_date),
                                   new SqlParameter("@UserId", obj.insert_user)
                               };
            DataSet ds = obj_dal.get(p, sp_name);
            return ds;
        }

        public DataSet getSaleReturnDetails(long returnid, long userid)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "get_sale_return_detail"),
                                   new SqlParameter("@ReturnId", returnid),
                                   new SqlParameter("@UserId", userid)
                               };
            DataSet ds = obj_dal.get(p, sp_name);
            return ds;
        }
    }
}
