﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using entity;
using dal_common;

namespace bal
{
   public class bal_purchase_report
    {
        string sp_name = "purchase_report_sp";
        dal obj_dal = new dal();

        public DataSet getGridviewData(Report obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "get_gdv_data"),
                                   new SqlParameter("@VendId", obj.vend_id),                                  
                                   new SqlParameter("@FromDate", obj.from_date),
                                   new SqlParameter("@ToDate", obj.to_date),
                                   new SqlParameter("@UserId", obj.insert_user)
                               };
            DataSet ds = obj_dal.get(p, sp_name);
            return ds;
        }

        public DataSet getPurchaseDetails(long purchaseid, long userid)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "get_purchase_detail"),
                                   new SqlParameter("@PurchaseId", purchaseid),
                                   new SqlParameter("@UserId", userid)
                               };
            DataSet ds = obj_dal.get(p, sp_name);
            return ds;
        }
    }
}
