﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;

namespace bal
{
    public class bal_sale_return
    {
        dal obj_dal = new dal();
        string spname = "sale_return_sp";

        public DataSet loadItemsCmb(long userid)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode", "load_items_cmb"),
                                   new SqlParameter("@UserId", userid)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;
        }
        public long insertSale(entity_sale_return obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_sale_return"),
                                   new SqlParameter("@CustId", obj.customer_id),
                                   new SqlParameter("@ReturnTime",obj.sale_time ),
                                   //new SqlParameter("@DueDate", obj.due_date),
                                   new SqlParameter("@TotalDiscount", obj.total_discount),
                                   new SqlParameter("@TotalAmount", obj.total_amount),
                                   new SqlParameter("@PayableAmount",obj.payable_amount ),
                                   new SqlParameter("@PaidAmount", obj.paid_amount),
                                   new SqlParameter("@PendingAmount",obj.pending_amount ),
                                   new SqlParameter("@InsertedBy", obj.insert_user )
                                   //new SqlParameter("@TVPItems", item_dt),
                                   //new SqlParameter("@TVPImg", img_dt)
                                   
                               };
            long saleid = Convert.ToInt64(obj_dal.get(p, spname).Tables[0].Rows[0]["saleid"]);
            return saleid;
        }

        public int insertItems(DataTable item_dt, long saleid, long user)
        {
            SqlParameter[] p ={
                                new SqlParameter("@Mode", "insert_items"),
                                new SqlParameter("@TVPInsertItems", item_dt),
                                new SqlParameter("@ReturnId", saleid),
                                new SqlParameter("@InsertedBy", user)
                              };
            int check = obj_dal.set(p, spname);
            return check;
        }

        public int insertImages(DataTable img_dt, long saleid, long user)
        {
            SqlParameter[] p ={
                                new SqlParameter("@Mode", "insert_images"),
                                new SqlParameter("@TVPInsertImages", img_dt),
                                new SqlParameter("@ReturnId", saleid),
                                new SqlParameter("@InsertedBy", user)
                              };
            int check = obj_dal.set(p, spname);
            return check;
        }
    }
}
