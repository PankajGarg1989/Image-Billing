﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;


namespace bal
{

    public class bal_company
    {
        dal obj_dal = new dal();
        string spname = "company_sp";

        public DataSet loadCompanyInfo(long user)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","get_company_info"),
                                   new SqlParameter("@UserId", user)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;

        }
        public int saveCompanyInfo(entity_comp_info obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_company_info"),
                                   new SqlParameter("@Company", obj.company_name ),
                                   new SqlParameter("@Business",obj.business_name),
                                   new SqlParameter("@Address",obj.address),
                                   new SqlParameter("@Phone",obj.phone_no),
                                   new SqlParameter("@Email",obj.email),
                                   new SqlParameter("@GSTNo",obj.gst_no),
                                   new SqlParameter("@PANNo",obj.pan_no),
                                   new SqlParameter("@AdhaarNo",obj.adhaar_no),
                                   new SqlParameter("@InsertedBy",obj.insert_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }

        public int editCompanyInfo(entity_comp_info obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_company_info"),
                                   new SqlParameter("@Company", obj.company_name ),
                                   new SqlParameter("@Business",obj.business_name),
                                   new SqlParameter("@Address",obj.address),
                                   new SqlParameter("@Phone",obj.phone_no),
                                   new SqlParameter("@Email",obj.email),
                                   new SqlParameter("@GSTNo",obj.gst_no),
                                   new SqlParameter("@PANNo",obj.pan_no),
                                   new SqlParameter("@AdhaarNo",obj.adhaar_no),
                                   new SqlParameter("@CompanyId", obj.id),
                                   new SqlParameter("@ModifiedBy",obj.modify_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }

        public int changeCompanyStatus(entity_comp_info obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_company_status"),
                                   new SqlParameter("@CompanyId", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }
    }
}
