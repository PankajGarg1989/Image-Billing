﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;


namespace bal
{

    public class bal_pay_mode
    {
        dal obj_dal = new dal();
        string spname = "paymode_sp";

        public DataSet loadPayModes(long user)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","get_paymodes"),
                                   new SqlParameter("@UserId", user)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;

        }
        public int savePayModes(entity_m_pay_mode obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_paymodes"),
                                   new SqlParameter("@Name", obj.p_mode_name ),
                                   new SqlParameter("@InsertedBy",obj.insert_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }
        public int changePayModeStatus(entity_m_pay_mode obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_paymode_status"),
                                   new SqlParameter("@Id", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }
        
    }
}
