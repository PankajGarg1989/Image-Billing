﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using entity;
using dal_common;


namespace bal
{

    public class bal_items
    {
        dal obj_dal = new dal();
        string spname = "items_sp";

        public DataSet loadItems(long user)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","get_items"),
                                   new SqlParameter("@UserId", user)
                               };
            DataSet ds = obj_dal.get(p, spname);
            return ds;

        }
        public int saveItems(entity_m_items obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","insert_items"),
                                   new SqlParameter("@Name", obj.item_name ),
                                   new SqlParameter("@Description",obj.item_description),
                                   new SqlParameter("@Price",obj.selling_price),
                                   new SqlParameter("@InsertedBy",obj.insert_user)
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }

        public int editItems(entity_m_items obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_items"),
                                   new SqlParameter("@Name", obj.item_name ),
                                   new SqlParameter("@Description",obj.item_description),
                                   new SqlParameter("@Price",obj.selling_price),
                                   new SqlParameter("@Id", obj.id),
                                   new SqlParameter("@ModifiedBy",obj.modify_user)
                               
                               };
            int check = obj_dal.set(p, spname);
            return check;

        }

        public int changeItemStatus(entity_m_items obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","update_item_status"),
                                   new SqlParameter("@Id", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }

        public int deleteItem(entity_m_items obj)
        {
            SqlParameter[] p = {
                                   new SqlParameter("@Mode","delete_item"),
                                   new SqlParameter("@Id", obj.id)
                               };
            int check = obj_dal.set(p, spname);
            return check;
        }
    }
}
