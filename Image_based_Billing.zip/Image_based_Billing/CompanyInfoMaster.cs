﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using entity;
using bal;

namespace Image_Based_Billing
{
    public partial class CompanyInfoMaster : Form
    {
        entity_comp_info obj_entity_comp_info;
        bal_company obj_bal_company = new bal_company();
        common obj_common = new common();
        public CompanyInfoMaster()
        {
            InitializeComponent();
            bindCompanyInfo();
            lbl_alert.Visible = false;

        }

        protected void bindCompanyInfo()
        {
            try
            {
                gdv_companies.Columns.Remove(gdv_companies.Columns["btn_status"]);
            }
            catch (Exception)
            {

            }
            DataSet ds = obj_bal_company.loadCompanyInfo(Login._userid);

            DataView dv = new DataView(ds.Tables[0]);

            DataTable dt = dv.ToTable(false, "company_name", "business_name", "address", "phone_no", "email", "gst_no", "pan_no", "adhaar_no", "id", "status");
            gdv_companies.DataSource = dt;


            DataGridViewButtonColumn btn1 = new DataGridViewButtonColumn();
            btn1.HeaderText = "";
            btn1.Name = "btn_status";
            btn1.DataPropertyName = "status";
            gdv_companies.Columns.Add(btn1);

            gdv_companies.Columns["btn_edit"].DisplayIndex = 9;
            gdv_companies.Columns["btn_status"].DisplayIndex = 10;

            gdv_companies.Columns["id"].Visible = false;
            gdv_companies.Columns["status"].Visible = false;




        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private int saveCompanyInfo()
        {
            obj_entity_comp_info = new entity_comp_info();
            obj_entity_comp_info.company_name = txt_comp_name.Text.Trim();
            obj_entity_comp_info.business_name = txt_business_name.Text.Trim();
            obj_entity_comp_info.address = txt_address.Text.Trim();
            obj_entity_comp_info.phone_no = txt_phone.Text.Trim();
            obj_entity_comp_info.email = txt_email.Text.Trim();
            obj_entity_comp_info.gst_no = txt_gstno.Text.Trim();
            obj_entity_comp_info.pan_no = txt_panno.Text.Trim();
            obj_entity_comp_info.adhaar_no = txt_aadharno.Text.Trim();
            obj_entity_comp_info.insert_user = Login._userid;
            int i = obj_bal_company.saveCompanyInfo(obj_entity_comp_info);
            return i;
        }

        private int updateCompanyInfo()
        {
            obj_entity_comp_info = new entity_comp_info();
            obj_entity_comp_info.company_name = txt_comp_name.Text.Trim();
            obj_entity_comp_info.business_name = txt_business_name.Text.Trim();
            obj_entity_comp_info.address = txt_address.Text.Trim();
            obj_entity_comp_info.phone_no = txt_phone.Text.Trim();
            obj_entity_comp_info.email = txt_email.Text.Trim();
            obj_entity_comp_info.gst_no = txt_gstno.Text.Trim();
            obj_entity_comp_info.pan_no = txt_panno.Text.Trim();
            obj_entity_comp_info.adhaar_no = txt_aadharno.Text.Trim();
            obj_entity_comp_info.id = Convert.ToInt64(lbl_company_id.Text);
            obj_entity_comp_info.modify_user = Login._userid;

            int i = obj_bal_company.editCompanyInfo(obj_entity_comp_info);

            return i;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            obj_common.ClearInputs(Parent.Controls);
        }

        private void CompanyInfo_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void gdv_companies_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {

            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                // right alignment might actually make more sense for numbers
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
        }

        private void gdv_companies_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var senderGrid = (DataGridView)sender;
                DataGridViewRow row = gdv_companies.Rows[e.RowIndex];
                lbl_company_id.Text = row.Cells["id"].Value.ToString();
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    if (e.ColumnIndex == 0)
                    {
                        txt_comp_name.Text = row.Cells["company_name"].Value.ToString();
                        txt_business_name.Text = row.Cells["business_name"].Value.ToString();
                        txt_address.Text = row.Cells["address"].Value.ToString();
                        txt_phone.Text = row.Cells["phone_no"].Value.ToString();
                        txt_email.Text = row.Cells["email"].Value.ToString();
                        txt_gstno.Text = row.Cells["gst_no"].Value.ToString();
                        txt_panno.Text = row.Cells["pan_no"].Value.ToString();
                        txt_aadharno.Text = row.Cells["adhaar_no"].Value.ToString();
                        btn_save.Text = "Update";
                    }
                    else
                    {
                        //MessageBox.Show(((DataGridViewButtonCell)(row.Cells[1])).Value.ToString());
                        obj_entity_comp_info = new entity_comp_info();
                        obj_entity_comp_info.id = Convert.ToInt64(lbl_company_id.Text);
                        int i = obj_bal_company.changeCompanyStatus(obj_entity_comp_info);
                        if (i > 0)
                        {
                            lbl_alert.Text = "Operation completed Successfully";
                            lbl_alert.Visible = true;
                            bindCompanyInfo();
                        }
                        else
                        {
                            lbl_alert.Text = "Oops... Something went wrong";
                            lbl_alert.Visible = true;

                        }
                    }
                }
            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            int i = 0;
            if (btn_save.Text.ToLower() == "save")
            {
                i = saveCompanyInfo();

            }
            else
            {
                i = updateCompanyInfo();
            }
            if (i > 0)
            {
                lbl_company_id.Text = "0";
                btn_save.Text = "Save";
                lbl_alert.Text = "Saved Successfully";
                lbl_alert.Visible = true;
                obj_common.ClearInputs(Parent.Controls);
                bindCompanyInfo();
            }
            else
            {
                lbl_alert.Text = "Oops.. Something went wrong";
                lbl_alert.Visible = true;
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            obj_common.ClearInputs(Parent.Controls);
            lbl_alert.Text = "";
            btn_save.Text = "Save";
        }

        private void focusNext(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)
            {
                Control ctrl = (Control)sender;

                this.SelectNextControl(ctrl, true, true, true, true);
                e.SuppressKeyPress = true;

            }
            else
            {

            }

        }



        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txt_comp_name_KeyDown(object sender, KeyEventArgs e)
        {

        }




        //protected void clearControls()
        //{
        //    foreach (Control ctrl in this.Controls)
        //    {
        //       Utilities 
        //    }
        //}
    }
}
