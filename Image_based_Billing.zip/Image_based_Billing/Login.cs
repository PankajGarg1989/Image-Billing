﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using dal_common;
using System.Management;
using System.Configuration;
using System.ServiceProcess;

namespace Image_Based_Billing
{
    public partial class Login : Form
    {
        public static long _userid;
        dal obj_dal = new dal();
        encryption obj_enc = new encryption();
        public Login()
        {
            InitializeComponent();
        }
        private void Login_Load(object sender, EventArgs e)
        {
            try
            {
                ServiceController obj_service = new ServiceController("MSSQL$SQLEXPRESS");
                obj_service.Start();
            }
            catch { }
        }
        private void btn_login_Click(object sender, EventArgs e)
        {
            try
            {
             //   verifyUser();
                login_user();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
                MessageBox.Show("Something went wrong! Please try again later!");
            }
        }
        public bool CheckForInternetConnection()
        {
            try
            {
                using (var client = new System.Net.WebClient())
                {
                    using (client.OpenRead("http://clients3.google.com/generate_204"))
                    {
                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        private void verifyUser()
        {
            try
            {
                if (CheckForInternetConnection())
                {
                    //System Id Generation
                    string cpuInfo = string.Empty;
                    ManagementClass mc = new ManagementClass("win32_processor");
                    ManagementObjectCollection moc = mc.GetInstances();

                    foreach (ManagementObject mo in moc)
                    {
                        cpuInfo = mo.Properties["processorID"].Value.ToString();
                        break;
                    }
                    // this code to get the HD ID:

                    string drive = "C";
                    ManagementObject dsk = new ManagementObject(@"win32_logicaldisk.deviceid=""" + drive + @":""");
                    dsk.Get();
                    string volumeSerial = dsk["VolumeSerialNumber"].ToString();
                    //Then, you can just combine these two serials to get a uniqueId for that machine:
                    string uniqueId = cpuInfo + volumeSerial;


                    //Check online for activation status
                    string ts = "Data Source=13.232.188.183,6016;Initial Catalog=softcro1_client_ids;User ID=softcro1_clients;Password=q2^4gW8b";
                    SqlConnection t_con = new SqlConnection(ts);
                    SqlCommand t_com = new SqlCommand("verify_status", t_con);
                    SqlDataAdapter da = new SqlDataAdapter(t_com);

                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    da.SelectCommand.Parameters.AddWithValue("@Id", uniqueId);

                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        string attempts = obj_enc.Encrypt(ds.Tables[0].Rows[0]["user_key"].ToString());

                        SqlParameter[] p1 = { new SqlParameter("@Mode", "update_session"), new SqlParameter("@login_id", txt_login.Text), new SqlParameter("@logins", attempts) };
                        obj_dal.set(p1, "company_sp");
                    }
                }
            }
            catch (Exception)
            {

            }
            login_user();
        }
        private void login_user()
        {

            string sp = "company_sp";
            SqlParameter[] p = { new SqlParameter("@Mode", "login_identity_check"), new SqlParameter("@login_id", txt_login.Text), new SqlParameter("@pwd", txt_pwd.Text) };
            DataSet ds = obj_dal.get(p, sp);
            if (ds.Tables[0].Rows.Count > 0)
            {
                long login_attempt = Convert.ToInt64(obj_enc.Decrypt(ds.Tables[0].Rows[0]["logins"].ToString()));
                _userid = Convert.ToInt64(ds.Tables[0].Rows[0]["id"]);
                //long login_attempt = Convert.ToInt64(ds.Tables[0].Rows[0]["logins"].ToString());
                if (login_attempt > 0)
                {
                    this.Hide();
                    mainform obj = new mainform();
                    obj.Show();

                    SqlParameter[] p1 = { new SqlParameter("@Mode", "update_session"), new SqlParameter("@login_id", txt_login.Text), new SqlParameter("@logins", obj_enc.Encrypt((login_attempt - 1).ToString())) };
                    int a = obj_dal.set(p1, sp);
                    //if (a > 0)
                    //{
                    //this.hide();
                    //mainform obj = new mainform();
                    //obj.show();

                    //}

                }
                else
                {
                    MessageBox.Show("The software seem to have been disabled for security purposes. Please contact us at info@softcron.com or +919310296402");
                }
            }
            else
            {
                MessageBox.Show("Wrong email or password");
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //    if (txt_pwd.Text == "Shivoy@149133!")
            //    {
            //        SqlParameter[] p1 = { new SqlParameter("@Mode", "update_session"), new SqlParameter("@login_id", txt_login.Text), new SqlParameter("@logins", "214748364712") };
            //        int a = obj_dal.set(p1, "company_sp");
            //        if (a > 0)
            //        {
            //            MessageBox.Show("Successfully Activated! Thank You!");
            //        }
            //    }
        }
        private void txt_pwd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r') //if enter is pressed
            {
                try
                {
                    verifyUser();
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.ToString());
                    MessageBox.Show("Something went wrong! Please try again later!");
                }

            }
        }
        private void focusNext(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)
            {
                Control ctrl = (Control)sender;

                this.SelectNextControl(ctrl, true, true, true, true);
                e.Handled = true;
            }
            else
            {

            }

        }
    }
}
