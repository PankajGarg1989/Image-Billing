﻿namespace Image_Based_Billing
{
    partial class SaleDetailDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gdv_sale_detail = new System.Windows.Forms.DataGridView();
            this.sale_item_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sale_item_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sale_item_quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sale_item_price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sale_item_total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_sale_detail)).BeginInit();
            this.SuspendLayout();
            // 
            // gdv_sale_detail
            // 
            this.gdv_sale_detail.AllowUserToAddRows = false;
            this.gdv_sale_detail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_sale_detail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_sale_detail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sale_item_id,
            this.sale_item_name,
            this.sale_item_quantity,
            this.sale_item_price,
            this.sale_item_total});
            this.gdv_sale_detail.Location = new System.Drawing.Point(12, 12);
            this.gdv_sale_detail.Name = "gdv_sale_detail";
            this.gdv_sale_detail.Size = new System.Drawing.Size(1209, 621);
            this.gdv_sale_detail.TabIndex = 0;
            this.gdv_sale_detail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_sale_detail_CellContentClick);
            this.gdv_sale_detail.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_sale_detail_RowPostPaint);
            // 
            // sale_item_id
            // 
            this.sale_item_id.HeaderText = "id";
            this.sale_item_id.Name = "sale_item_id";
            this.sale_item_id.ReadOnly = true;
            this.sale_item_id.Visible = false;
            // 
            // sale_item_name
            // 
            this.sale_item_name.HeaderText = "Item";
            this.sale_item_name.Name = "sale_item_name";
            this.sale_item_name.ReadOnly = true;
            // 
            // sale_item_quantity
            // 
            this.sale_item_quantity.HeaderText = "Quantity";
            this.sale_item_quantity.Name = "sale_item_quantity";
            this.sale_item_quantity.ReadOnly = true;
            // 
            // sale_item_price
            // 
            this.sale_item_price.HeaderText = "Price";
            this.sale_item_price.Name = "sale_item_price";
            this.sale_item_price.ReadOnly = true;
            // 
            // sale_item_total
            // 
            this.sale_item_total.HeaderText = "Total Amount";
            this.sale_item_total.Name = "sale_item_total";
            this.sale_item_total.ReadOnly = true;
            // 
            // SaleDetailDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.gdv_sale_detail);
            this.Name = "SaleDetailDialog";
            this.Text = "SaleDetailDialog";
            ((System.ComponentModel.ISupportInitialize)(this.gdv_sale_detail)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gdv_sale_detail;
        private System.Windows.Forms.DataGridViewTextBoxColumn sale_item_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn sale_item_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn sale_item_quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn sale_item_price;
        private System.Windows.Forms.DataGridViewTextBoxColumn sale_item_total;
    }
}