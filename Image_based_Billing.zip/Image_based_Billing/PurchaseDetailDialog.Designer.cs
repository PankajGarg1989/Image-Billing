﻿namespace Image_Based_Billing
{
    partial class PurchaseDetailDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gdv_purchase_detail = new System.Windows.Forms.DataGridView();
            this.purchase_item_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchase_item_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchase_item_quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchase_item_price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchase_item_total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_purchase_detail)).BeginInit();
            this.SuspendLayout();
            // 
            // gdv_purchase_detail
            // 
            this.gdv_purchase_detail.AllowUserToAddRows = false;
            this.gdv_purchase_detail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_purchase_detail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_purchase_detail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.purchase_item_id,
            this.purchase_item_name,
            this.purchase_item_quantity,
            this.purchase_item_price,
            this.purchase_item_total});
            this.gdv_purchase_detail.Location = new System.Drawing.Point(12, 12);
            this.gdv_purchase_detail.Name = "gdv_purchase_detail";
            this.gdv_purchase_detail.Size = new System.Drawing.Size(1228, 625);
            this.gdv_purchase_detail.TabIndex = 1;
            this.gdv_purchase_detail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_purchase_detail_CellContentClick);
            this.gdv_purchase_detail.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_purchase_detail_RowPostPaint);
            // 
            // purchase_item_id
            // 
            this.purchase_item_id.HeaderText = "id";
            this.purchase_item_id.Name = "purchase_item_id";
            this.purchase_item_id.ReadOnly = true;
            this.purchase_item_id.Visible = false;
            // 
            // purchase_item_name
            // 
            this.purchase_item_name.HeaderText = "Item";
            this.purchase_item_name.Name = "purchase_item_name";
            this.purchase_item_name.ReadOnly = true;
            // 
            // purchase_item_quantity
            // 
            this.purchase_item_quantity.HeaderText = "Quantity";
            this.purchase_item_quantity.Name = "purchase_item_quantity";
            this.purchase_item_quantity.ReadOnly = true;
            // 
            // purchase_item_price
            // 
            this.purchase_item_price.HeaderText = "Price";
            this.purchase_item_price.Name = "purchase_item_price";
            this.purchase_item_price.ReadOnly = true;
            // 
            // purchase_item_total
            // 
            this.purchase_item_total.HeaderText = "Total Amount";
            this.purchase_item_total.Name = "purchase_item_total";
            this.purchase_item_total.ReadOnly = true;
            // 
            // PurchaseDetailDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.gdv_purchase_detail);
            this.Name = "PurchaseDetailDialog";
            this.Text = "PurchaseDetailDialog";
            ((System.ComponentModel.ISupportInitialize)(this.gdv_purchase_detail)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gdv_purchase_detail;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchase_item_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchase_item_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchase_item_quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchase_item_price;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchase_item_total;
    }
}