﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Service_Management_Solution
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("calc.exe");
            p.WaitForInputIdle();
            //NativeMethods.SetParent(p.MainWindowHandle, this.Handle);
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }
    }
}
