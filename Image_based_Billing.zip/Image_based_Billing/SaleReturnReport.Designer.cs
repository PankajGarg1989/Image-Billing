﻿namespace Image_Based_Billing
{
    partial class SaleReturnReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gdv_report = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.dtp_to_date = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dtp_from_date = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.mcc_customer = new VMultiColumnComboBox.MultiColumComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_excel_export = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_gdv_sale_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_cust_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_cust_phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_cust_address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_sale_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_payable_amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_view = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_report)).BeginInit();
            this.SuspendLayout();
            // 
            // gdv_report
            // 
            this.gdv_report.AllowUserToAddRows = false;
            this.gdv_report.AllowUserToDeleteRows = false;
            this.gdv_report.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_report.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gdv_report.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdv_report.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gdv_report.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_report.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_sale_id,
            this.txt_gdv_cust_id,
            this.txt_gdv_customer,
            this.txt_gdv_cust_phone,
            this.txt_gdv_cust_address,
            this.txt_gdv_sale_date,
            this.txt_gdv_payable_amount,
            this.btn_view});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gdv_report.DefaultCellStyle = dataGridViewCellStyle2;
            this.gdv_report.Location = new System.Drawing.Point(124, 289);
            this.gdv_report.Name = "gdv_report";
            this.gdv_report.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdv_report.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gdv_report.Size = new System.Drawing.Size(1083, 297);
            this.gdv_report.TabIndex = 757;
            this.gdv_report.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_report_CellContentClick_1);
            this.gdv_report.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_report_RowPostPaint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(120, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 20);
            this.label4.TabIndex = 763;
            this.label4.Text = "Sale Date";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // dtp_to_date
            // 
            this.dtp_to_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_to_date.Location = new System.Drawing.Point(757, 160);
            this.dtp_to_date.Name = "dtp_to_date";
            this.dtp_to_date.Size = new System.Drawing.Size(300, 26);
            this.dtp_to_date.TabIndex = 754;
            this.dtp_to_date.ValueChanged += new System.EventHandler(this.dtp_to_date_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(636, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 20);
            this.label1.TabIndex = 762;
            this.label1.Text = "To";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dtp_from_date
            // 
            this.dtp_from_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_from_date.Location = new System.Drawing.Point(228, 159);
            this.dtp_from_date.Name = "dtp_from_date";
            this.dtp_from_date.Size = new System.Drawing.Size(300, 26);
            this.dtp_from_date.TabIndex = 753;
            this.dtp_from_date.Value = new System.DateTime(2017, 4, 1, 0, 0, 0, 0);
            this.dtp_from_date.ValueChanged += new System.EventHandler(this.dtp_from_date_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(120, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 761;
            this.label2.Text = "Customer";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Company Name",
            "Phone Number",
            "Address"});
            this.comboBox1.Location = new System.Drawing.Point(1066, 116);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(101, 21);
            this.comboBox1.TabIndex = 760;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // mcc_customer
            // 
            this.mcc_customer.ColumnWidth = null;
            this.mcc_customer.DataSource = null;
            this.mcc_customer.DisplayColumnNo = 1;
            this.mcc_customer.DropDownHeight = 200;
            this.mcc_customer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mcc_customer.GridLines = VMultiColumnComboBox.GridLines.None;
            this.mcc_customer.Location = new System.Drawing.Point(228, 115);
            this.mcc_customer.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.mcc_customer.Name = "mcc_customer";
            this.mcc_customer.SelectedItem = null;
            this.mcc_customer.ShowHeader = false;
            this.mcc_customer.Size = new System.Drawing.Size(829, 24);
            this.mcc_customer.SourceDataHeader = null;
            this.mcc_customer.SourceDataString = null;
            this.mcc_customer.TabIndex = 752;
            this.mcc_customer.ValueColumnNo = 0;
            this.mcc_customer.Load += new System.EventHandler(this.mcc_customer_Load);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(332, 42);
            this.label3.TabIndex = 758;
            this.label3.Text = "Sale Return Report";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(605, 221);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 31);
            this.btn_search.TabIndex = 755;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_excel_export
            // 
            this.btn_excel_export.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_excel_export.Location = new System.Drawing.Point(703, 221);
            this.btn_excel_export.Name = "btn_excel_export";
            this.btn_excel_export.Size = new System.Drawing.Size(123, 31);
            this.btn_excel_export.TabIndex = 756;
            this.btn_excel_export.Text = "Export to Excel";
            this.btn_excel_export.UseVisualStyleBackColor = true;
            this.btn_excel_export.Visible = false;
            this.btn_excel_export.Click += new System.EventHandler(this.btn_excel_export_Click);
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(-10, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1378, 2);
            this.label10.TabIndex = 759;
            this.label10.Text = "  ";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // txt_gdv_sale_id
            // 
            this.txt_gdv_sale_id.HeaderText = "";
            this.txt_gdv_sale_id.Name = "txt_gdv_sale_id";
            this.txt_gdv_sale_id.ReadOnly = true;
            this.txt_gdv_sale_id.Visible = false;
            // 
            // txt_gdv_cust_id
            // 
            this.txt_gdv_cust_id.HeaderText = "";
            this.txt_gdv_cust_id.Name = "txt_gdv_cust_id";
            this.txt_gdv_cust_id.ReadOnly = true;
            this.txt_gdv_cust_id.Visible = false;
            // 
            // txt_gdv_customer
            // 
            this.txt_gdv_customer.HeaderText = "Customer";
            this.txt_gdv_customer.Name = "txt_gdv_customer";
            this.txt_gdv_customer.ReadOnly = true;
            // 
            // txt_gdv_cust_phone
            // 
            this.txt_gdv_cust_phone.HeaderText = "Customer Phone";
            this.txt_gdv_cust_phone.Name = "txt_gdv_cust_phone";
            this.txt_gdv_cust_phone.ReadOnly = true;
            // 
            // txt_gdv_cust_address
            // 
            this.txt_gdv_cust_address.HeaderText = "Address";
            this.txt_gdv_cust_address.Name = "txt_gdv_cust_address";
            this.txt_gdv_cust_address.ReadOnly = true;
            // 
            // txt_gdv_sale_date
            // 
            this.txt_gdv_sale_date.HeaderText = "Return Date";
            this.txt_gdv_sale_date.Name = "txt_gdv_sale_date";
            this.txt_gdv_sale_date.ReadOnly = true;
            // 
            // txt_gdv_payable_amount
            // 
            this.txt_gdv_payable_amount.HeaderText = "Return Value";
            this.txt_gdv_payable_amount.Name = "txt_gdv_payable_amount";
            this.txt_gdv_payable_amount.ReadOnly = true;
            // 
            // btn_view
            // 
            this.btn_view.HeaderText = "";
            this.btn_view.Name = "btn_view";
            this.btn_view.ReadOnly = true;
            this.btn_view.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.btn_view.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.btn_view.Text = "Details";
            this.btn_view.UseColumnTextForButtonValue = true;
            // 
            // SaleReturnReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 721);
            this.Controls.Add(this.gdv_report);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtp_to_date);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtp_from_date);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.mcc_customer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_excel_export);
            this.Controls.Add(this.label10);
            this.Name = "SaleReturnReport";
            this.Text = "SaleReturnReport";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.SaleReturnReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gdv_report)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gdv_report;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtp_to_date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtp_from_date;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private VMultiColumnComboBox.MultiColumComboBox mcc_customer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_excel_export;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_sale_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_cust_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_cust_phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_cust_address;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_sale_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_payable_amount;
        private System.Windows.Forms.DataGridViewButtonColumn btn_view;
    }
}