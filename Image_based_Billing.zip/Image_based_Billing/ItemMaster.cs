﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using entity;
using bal;


namespace Image_Based_Billing
{
    public partial class ItemMaster : Form
    {
        entity_m_items obj_en_m_items;
        bal_items obj_bal_items = new bal_items();
        common obj_common = new common();
        public ItemMaster()
        {
            InitializeComponent();
            loadGdv();
            lbl_alert.Visible = false;
        }

        private void loadGdv()
        {
            try
            {
                gdv_items.Columns.Remove(gdv_items.Columns["btn_status"]);

            }
            catch (Exception)
            {

            }
            DataSet ds = obj_bal_items.loadItems(Login._userid);

            DataGridViewButtonColumn btn1 = new DataGridViewButtonColumn();
            btn1.HeaderText = "";
            btn1.Name = "btn_status";
            btn1.DataPropertyName = "status";
            gdv_items.Columns.Add(btn1);

            gdv_items.AutoGenerateColumns = false;
            gdv_items.DataSource = ds.Tables[0];
            gdv_items.Columns[0].DataPropertyName = "id";
            gdv_items.Columns[1].DataPropertyName = "item_name";
            gdv_items.Columns[2].DataPropertyName = "item_description";
            gdv_items.Columns[3].DataPropertyName = "selling_price";

        }


        private void btn_save_Click(object sender, EventArgs e)
        {

            if (txt_item_name.Text.Trim() != "")
            {
                int check = 0;
                obj_en_m_items = new entity_m_items();
                obj_en_m_items.item_name = txt_item_name.Text.Trim();
                obj_en_m_items.item_description = txt_description.Text.Trim();
                try
                {
                    obj_en_m_items.selling_price = Convert.ToDecimal(txt_selling_price.Text.Trim());
                }
                catch (Exception)
                {
                    obj_en_m_items.selling_price = 0;
                }
                if (btn_save.Text.ToLower() == "save")
                {
                    check = saveItem(obj_en_m_items);
                }
                else
                {
                    check = updateItem(obj_en_m_items);
                }

                if (check > 0)
                {
                    lbl_item_id.Text = "0";
                    btn_save.Text = "Save";
                    lbl_alert.Text = "Saved Successfully";
                    lbl_alert.Visible = true;
                    obj_common.ClearInputs(Parent.Controls);
                    loadGdv();
                }
                else
                {
                    lbl_alert.Text = "Oops.. Something went wrong";
                    lbl_alert.Visible = true;
                }
            }

        }



        private int saveItem(entity_m_items obj)
        {
            obj.insert_user = Login._userid;
            int i = obj_bal_items.saveItems(obj);
            return i;
        }
        private int updateItem(entity_m_items obj)
        {
            obj.id = Convert.ToInt64(lbl_item_id.Text);
            obj.modify_user = Login._userid;
            int i = obj_bal_items.editItems(obj);
            return i;
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            obj_common.ClearInputs(Parent.Controls);
            lbl_alert.Text = "";
            btn_save.Text = "Save";
        }

        private void gdv_vendors_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                // right alignment might actually make more sense for numbers
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);

        }

        private void gdv_vendors_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var senderGrid = (DataGridView)sender;
                DataGridViewRow row = gdv_items.Rows[e.RowIndex];
                lbl_item_id.Text = Convert.ToString(row.Cells["txt_gdv_id"].Value);
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    if (e.ColumnIndex == 4)
                    {
                        txt_item_name.Text = row.Cells["txt_gdv_item_name"].Value.ToString();
                        txt_description.Text = row.Cells["txt_gdv_item_desc"].Value.ToString();
                        txt_selling_price.Text = row.Cells["txt_gdv_price"].Value.ToString();
                        btn_save.Text = "Update";
                    }
                    else
                    {
                        DialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Conditional", MessageBoxButtons.YesNo);
                        if (DialogResult == DialogResult.Yes)
                        {
                            int check = 0;
                            obj_en_m_items = new entity_m_items();
                            try
                            {
                                obj_en_m_items.id = Convert.ToInt64(lbl_item_id.Text);
                                if (e.ColumnIndex == 5)
                                {
                                    check = obj_bal_items.deleteItem(obj_en_m_items);
                                }
                                else
                                {
                                    check = obj_bal_items.changeItemStatus(obj_en_m_items);

                                }
                            }
                            catch (Exception)
                            {

                            }
                            if (check > 0)
                            {
                                lbl_alert.Text = "Operation Completed Successfully";
                                lbl_alert.Visible = true;
                                loadGdv();
                            }
                            else
                            {
                                lbl_alert.Text = "Oops... Something went wrong";
                                lbl_alert.Visible = true;

                            }
                        }

                    }
                }
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_search.Text) || txt_search.Text == "Search")
            {
                (gdv_items.DataSource as DataTable).DefaultView.RowFilter = string.Empty;
            }
            else
            {
                (gdv_items.DataSource as DataTable).DefaultView.RowFilter = "item_name LIKE '*" + txt_search.Text + "*'";
            }
        }

        private void ItemMaster_Load(object sender, EventArgs e)
        {

        }

        private void txt_search_Enter(object sender, EventArgs e)
        {
            if (txt_search.Text == "Search")
            {
                txt_search.Text = "";
            }
        }

        private void txt_search_Leave(object sender, EventArgs e)
        {
            if (txt_search.Text == "")
            {
                txt_search.Text = "Search";
            }
        }
    }
}
