﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using entity;
using bal;

namespace Image_Based_Billing
{

    public partial class TaxMaster : Form
    {
        entity_m_tax obj_entity_m_tax;
        bal_tax obj_bal_tax = new bal_tax();
        common obj_common = new common();
        public TaxMaster()
        {
            InitializeComponent();
            bindTaxes();
            lbl_alert.Visible = false;
        }

        protected void bindTaxes()
        {
            DataSet ds = obj_bal_tax.loadTax(Login._userid);
            gdv_taxes.AutoGenerateColumns = false;
            gdv_taxes.DataSource = ds.Tables[0];
            gdv_taxes.Columns[0].DataPropertyName = "id";
            gdv_taxes.Columns[1].DataPropertyName = "tax_name";
            gdv_taxes.Columns[2].DataPropertyName = "tax_value";


            //DataView dv = new DataView(ds.Tables[0]);
            //DataTable dt = dv.ToTable(false, "id", "tax_name", "tax_value");
            //gdv_taxes.DataSource = dt;
            //gdv_taxes.Columns["btn_edit"].DisplayIndex = 2;
            //gdv_taxes.Columns["id"].Visible = false;
        }
        private void TaxMaster_Load(object sender, EventArgs e)
        {

        }
        private void focusNext(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)
            {
                Control ctrl = (Control)sender;

                this.SelectNextControl(ctrl, true, true, true, true);
                e.SuppressKeyPress = true;
            }
            else
            {

            }

        }
        private void txt_Enter(object sender, EventArgs e)
        {
            NumericUpDown ctrl = (NumericUpDown)sender;
            ctrl.Select(0, ctrl.Text.Length);
        }
        private void btn_save_Click(object sender, EventArgs e)
        {

            int i = 0;
            if (btn_save.Text.ToLower() == "save")
            {
                i = saveTax();

            }
            else
            {
                i = updateTax();
            }
            if (i > 0)
            {
                lbl_alert.Text = "Saved Successfully";
                lbl_alert.Visible = true;
                obj_common.ClearInputs(Parent.Controls);
                bindTaxes();
                btn_save.Text = "Save";
            }
            else
            {
                lbl_alert.Text = "Oops.. Something went wrong";
                lbl_alert.Visible = true;
            }
        }

        private int updateTax()
        {
            int i = 0;
            obj_entity_m_tax = new entity_m_tax();
            obj_entity_m_tax.tax_name = txt_tax_name.Text.Trim();
            obj_entity_m_tax.modify_user = Login._userid;
            try
            {

                obj_entity_m_tax.tax_value = Convert.ToInt32(txt_tax_value.Text.Trim());
                obj_entity_m_tax.id = Convert.ToInt32(lbl_tax_id.Text);
                i = obj_bal_tax.editTax(obj_entity_m_tax);

            }
            catch (Exception)
            {

            }
            return i;
        }

        private int saveTax()
        {
            obj_entity_m_tax = new entity_m_tax();
            obj_entity_m_tax.tax_name = txt_tax_name.Text.Trim();
            obj_entity_m_tax.insert_user = Login._userid;
            int i = 0;
            try
            {
                obj_entity_m_tax.tax_value = Convert.ToInt32(txt_tax_value.Text.Trim());

                i = obj_bal_tax.saveTax(obj_entity_m_tax);
            }
            catch (Exception)
            {

            }
            return i;
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            obj_common.ClearInputs(Parent.Controls);
            btn_save.Text = "Save";
            lbl_alert.Text = "";
        }

        private void gdv_taxes_RowPostPaint(object sender, System.Windows.Forms.DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                // right alignment might actually make more sense for numbers
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);

        }

        private void gdv_taxes_CellContentClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var senderGrid = (DataGridView)sender;
                DataGridViewRow row = gdv_taxes.Rows[e.RowIndex];
                lbl_tax_id.Text = row.Cells["txt_gdv_tax_id"].Value.ToString();
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    if (e.ColumnIndex == 3)
                    {
                        txt_tax_name.Text = row.Cells["txt_gdv_tax_name"].Value.ToString();
                        txt_tax_value.Text = row.Cells["txt_gdv_tax_value"].Value.ToString();
                        btn_save.Text = "Update";
                    }
                    else if (e.ColumnIndex == 4)
                    {
                        obj_entity_m_tax = new entity_m_tax();
                        obj_entity_m_tax.id = Convert.ToInt32(lbl_tax_id.Text);
                        int i = obj_bal_tax.deleteTax(obj_entity_m_tax);
                        if (i > 0)
                        {
                            lbl_alert.Text = "Deleted Successfully";
                            lbl_alert.Visible = true;
                            bindTaxes();
                        }
                        else
                        {
                            lbl_alert.Text = "Oops... Something went wrong";
                            lbl_alert.Visible = true;

                        }
                    }
                }
            }
        }
        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txt_tax_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbl_tax_id_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void lbl_alert_Click(object sender, EventArgs e)
        {

        }

        private void txt_tax_value_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
