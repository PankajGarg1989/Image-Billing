﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bal;
using System.Drawing;

namespace Image_Based_Billing
{
    class common : System.Windows.Forms.Control
    {
        public void ClearInputs(ControlCollection ctrls)
        {
            try
            {
                foreach (Control ctrl in ctrls)
                {
                    if (ctrl is TextBox)
                        ((TextBox)ctrl).Text = string.Empty;
                    //((TextBox)ctrl).Text = "";
                    ClearInputs(ctrl.Controls);
                    if (ctrl is ComboBox)
                        ((ComboBox)ctrl).SelectedIndex = 0;
                    if (ctrl is RadioButton)
                        ((RadioButton)ctrl).Checked = false;
                    //if (ctrl is DataGridView)
                    //    ((DataGridView)ctrl).Rows.Clear();
                }
            }
            catch (Exception)
            {


            }
        }

        public string currentSessionDate()
        {
            string year = new bal.bal_session().getYear();
            return "04/01/"+year;

        }

        public bool validateFields(TextBox[] controls)
        {
            bool isValid = true;
            foreach (var control in controls.Where(e => String.IsNullOrWhiteSpace(e.Text)))
            {
                //errorProvider1.SetError(control, "Please fill the required field");
                isValid = false;
            }

            return isValid;
        }

        public void gdvRowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                // right alignment might actually make more sense for numbers
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);

        }
    }
}
