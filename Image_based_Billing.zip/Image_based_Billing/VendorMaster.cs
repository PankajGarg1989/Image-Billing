﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using entity;

using bal;

namespace Image_Based_Billing
{
    public partial class VendorMaster : Form
    {
        entity_m_vendor obj_entity_m_vendor;
        bal_vendor obj_bal_vendor = new bal_vendor();
        common obj_common = new common();
        public VendorMaster()
        {
            InitializeComponent();
            bindVendor();
            lbl_alert.Visible = false;

        }

        private void bindVendor()
        {
            try
            {
                gdv_vendors.Columns.Remove(gdv_vendors.Columns["btn_status"]);

            }
            catch (Exception)
            {

            }
            DataSet ds = obj_bal_vendor.loadVendor(Login._userid);

            DataGridViewButtonColumn btn1 = new DataGridViewButtonColumn();
            btn1.HeaderText = "";
            btn1.Name = "btn_status";
            btn1.DataPropertyName = "status";
            gdv_vendors.Columns.Add(btn1);

            gdv_vendors.AutoGenerateColumns = false;
            gdv_vendors.DataSource = ds.Tables[0];
            gdv_vendors.Columns[0].DataPropertyName = "id";
            gdv_vendors.Columns[2].DataPropertyName = "vend_name";            gdv_vendors.Columns[1].DataPropertyName = "vend_company";

            gdv_vendors.Columns[3].DataPropertyName = "vend_address";
            gdv_vendors.Columns[4].DataPropertyName = "vend_phone";
            gdv_vendors.Columns[5].DataPropertyName = "vend_mobile1";
            gdv_vendors.Columns[6].DataPropertyName = "vend_mobile2";
            gdv_vendors.Columns[7].DataPropertyName = "vend_email";
            //gdv_vendors.Columns[6].DataPropertyName = "vend_gst";
            //gdv_vendors.Columns[7].DataPropertyName = "vend_pan";
            //gdv_vendors.Columns[8].DataPropertyName = "vend_aadhar";

            ////gdv_vendors.Columns["btn_edit"].DisplayIndex = 9;
            ////gdv_vendors.Columns["btn_status"].DisplayIndex = 10;
            ////gdv_vendors.Columns["id"].Visible = false;
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (txt_comp_name.Text.Trim() != "")
            {
                obj_entity_m_vendor = new entity_m_vendor();
                obj_entity_m_vendor.vend_company = txt_comp_name.Text.Trim();
                //obj_entity_m_vendor.vend_name = txt_vendor_name.Text.Trim();

                obj_entity_m_vendor.vend_address = txt_address.Text.Trim();
                obj_entity_m_vendor.vend_phone = txt_phone.Text.Trim();
                obj_entity_m_vendor.vend_email = txt_email.Text.Trim();
                //obj_entity_m_vendor.vend_gst = txt_gstno.Text.Trim();
                //obj_entity_m_vendor.vend_pan = txt_panno.Text.Trim();
                //obj_entity_m_vendor.vend_aadhar = txt_aadharno.Text.Trim();

                int i = 0;
                if (btn_save.Text.ToLower() == "save")
                {
                    
                    i = saveVendor(obj_entity_m_vendor);

                }
                else
                {
                    i = updateVendor(obj_entity_m_vendor);
                }
                if (i > 0)
                {
                    lbl_vendor_id.Text = "0";
                    btn_save.Text = "Save";
                    lbl_alert.Text = "Saved Successfully";
                    lbl_alert.Visible = true;
                    obj_common.ClearInputs(Parent.Controls);
                    bindVendor();
                }
                else
                {
                    lbl_alert.Text = "Oops.. Something went wrong";
                    lbl_alert.Visible = true;
                }
            }
        }

        private int updateVendor(entity_m_vendor obj)
        {
            obj.modify_user = Login._userid;
            obj.id = Convert.ToInt64(lbl_vendor_id.Text);
            int i = obj_bal_vendor.editVendor(obj);
            return i;

        }

        private int saveVendor(entity_m_vendor obj)
        {
            obj.insert_user = Login._userid;
            int i = obj_bal_vendor.saveVendor(obj);
            return i;

        }

        private void txt_address_TextChanged(object sender, EventArgs e)
        {

        }

        private void VendorMaster_Load(object sender, EventArgs e)
        {

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            obj_common.ClearInputs(Parent.Controls);
            lbl_alert.Text = "";
            btn_save.Text = "Save";
        }
        private void gdv_vendors_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                // right alignment might actually make more sense for numbers
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);

        }
        private void gdv_vendors_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            DataGridViewRow row = gdv_vendors.Rows[e.RowIndex];
            lbl_vendor_id.Text = Convert.ToString(row.Cells["vid"].Value);
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 11)
                {
                    txt_comp_name.Text = row.Cells["gdv_txt_vend_company"].Value.ToString();
                    //txt_vendor_name.Text = row.Cells["gdv_txt_vend_name"].Value.ToString();
                    txt_address.Text = row.Cells["gdv_txt_vend_address"].Value.ToString();
                    txt_phone.Text = row.Cells["gdv_txt_vend_phone"].Value.ToString();
                    txt_mobile1.Text = row.Cells["txt_gdv_vend_mobile1"].Value.ToString();
                    txt_mobile2.Text = row.Cells["txt_gdv_vend_mobile1"].Value.ToString();
                    txt_email.Text = row.Cells["gdv_txt_vend_email"].Value.ToString();
                    //txt_gstno.Text = row.Cells["gdv_txt_vend_gst"].Value.ToString();
                    //txt_panno.Text = row.Cells["gdv_txt_vend_pan"].Value.ToString();
                    //txt_aadharno.Text = row.Cells["gdv_txt_vend_aadhar"].Value.ToString();
                    btn_save.Text = "Update";
                }
                else if (e.ColumnIndex == gdv_vendors.Columns.IndexOf(gdv_vendors.Columns["btn_delete"]))
                {
                    DialogResult = MessageBox.Show("Are you sure you want to delete this record? All Related data will be wiped out!! ", "Conditional", MessageBoxButtons.YesNo);
                    if (DialogResult == DialogResult.Yes)
                    {
                        obj_entity_m_vendor = new entity_m_vendor();
                        obj_entity_m_vendor.id = Convert.ToInt64(lbl_vendor_id.Text);
                        int i = obj_bal_vendor.deleteVendor(obj_entity_m_vendor);
                        if (i > 0)
                        {
                            lbl_alert.Text = "Operation Completed Successfully";
                            lbl_alert.Visible = true;
                            bindVendor();
                        }
                        else
                        {
                            lbl_alert.Text = "Oops... Something went wrong";
                            lbl_alert.Visible = true;

                        }
                    }
                }
                else
                {
                    obj_entity_m_vendor = new entity_m_vendor();
                    obj_entity_m_vendor.id = Convert.ToInt64(lbl_vendor_id.Text);
                    int i = obj_bal_vendor.changeVendorStatus(obj_entity_m_vendor);
                    if (i > 0)
                    {
                        lbl_alert.Text = "Operation Completed Successfully";
                        lbl_alert.Visible = true;
                        bindVendor();
                    }
                    else
                    {
                        lbl_alert.Text = "Oops... Something went wrong";
                        lbl_alert.Visible = true;

                    }
                }
            }
        }
        public void focusNext(object sender, KeyEventArgs e)
        {

            if (e.KeyValue == 13)
            {
                Control ctrl = (Control)sender;

                this.SelectNextControl(ctrl, true, true, true, true);
                e.SuppressKeyPress = true;
            }
            else
            {

            }

        }
    }
}
