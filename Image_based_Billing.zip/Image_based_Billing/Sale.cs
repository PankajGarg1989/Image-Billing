﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using bal;
using entity;

namespace Image_Based_Billing
{
    public partial class Sale : Form
    {
        public static bool _reload_mcccustomer = false;

        entity_sale obj_en_sale;
        common obj_common = new common();
        bal_common obj_bal_common = new bal_common();
        bal_sale obj_bal_sale = new bal_sale();
        //bal_customer obj_bal_cust = new bal_customer();
        public Sale()
        {
            InitializeComponent();

            comboBox1.SelectedIndex = 0;

            mccCustomerLoad();
            //setItemCmb();

            fillItemCMB();

        }

        private void fillItemCMB()
        {
            cmb_item_name.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cmb_item_name.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection ac_items = new AutoCompleteStringCollection();

            DataSet ds = obj_bal_sale.loadItemsCmb(Login._userid);
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                ac_items.Add(row["item_name"].ToString());
            }
            //cmb_item_name.DataSource = ac_items;
            cmb_item_name.AutoCompleteCustomSource = ac_items;
        }

        public void mccCustomerLoad()
        {
            mcc_customer.Clear();
            mcc_customer.SourceDataString = new string[4] { "cust_company", "cust_phone", "cust_address", "id" };
            mcc_customer.ColumnWidth = new string[4] { "300", "150", "500", "0" };
            mcc_customer.DataSource = new bal_customer().loadCustomer(Login._userid).Tables[0];
            mcc_customer.DisplayColumnNo = 0;
            mcc_customer.ValueColumnNo = 3;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            mcc_customer.DisplayColumnNo = comboBox1.SelectedIndex;
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void btn_item_add_Click(object sender, EventArgs e)
        {
            int count1 = txt_item_price.Text.Trim().Split('.').Length - 1;
            int count2 = txt_item_quantity.Text.Trim().Split('.').Length - 1;
            if (count1 < 2 && count2 < 2)
            {
                TextBox[] controls = { txt_item_price, txt_item_quantity, txt_item_total };
                if (obj_common.validateFields(controls) && cmb_item_name.Text.Trim() != "")                                            // && cmb_item_name.SelectedValue != null && cmb_item_name.SelectedValue.ToString() !="0_0")
                {
                    DataGridViewRow row = (DataGridViewRow)gdv_item.Rows[0].Clone();

                    row.Cells[0].Value = cmb_item_name.Text.Trim();                                   //cmb_item_name.SelectedValue.ToString().Split('_')[0];
                    row.Cells[1].Value = cmb_item_name.Text.Trim();
                    row.Cells[2].Value = txt_item_price.Text.Trim();
                    row.Cells[3].Value = txt_item_quantity.Text.Trim();
                    //row.Cells[4].Value = (txt_item_disc_percent.Text.Trim() == "") ? "0" : txt_item_disc_percent.Text.Trim();
                    //row.Cells[5].Value = (txt_item_disc_amt.Text.Trim() == "") ? "0" : txt_item_disc_amt.Text.Trim();
                    row.Cells[6].Value = txt_item_total.Text.Trim();
                    gdv_item.Rows.Add(row);

                    ////clear add items textboxes
                    //cmb_item_name.DataSource = null;
                    //txt_item_disc_percent.Text = "";
                    //txt_item_disc_amt.Text = "";
                    foreach (var control in controls)
                    {
                        control.Text = "";
                    }
                    cmb_item_name.Text = "";
                    calcFinal();
                    //setItemCmb();
                }
            }
            else
            {
                MessageBox.Show("Cannot Enter more than one decimal!");
            }
        }

        private void gdv_item_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridView sendergdv = (DataGridView)sender;
                    DataGridViewRow row = sendergdv.Rows[e.RowIndex];
                    if (sendergdv.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex < sendergdv.Rows.Count - 1)
                    {
                        sendergdv.Rows.RemoveAt(e.RowIndex);
                    }
                    calcFinal();
                }
            }
            catch (Exception)
            {

            }
        }

        private void gdv_item_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            obj_common.gdvRowPostPaint(sender, e);
        }

        private void cmb_item_name_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void cmb_item_name_KeyUp(object sender, KeyEventArgs e)
        {
            ////trigger  only  on alphanumeric entry 
            //if (e.KeyValue >= 48 && e.KeyValue <= 57)
            //{
            //    setItemCmb();
            //}
            //else if (e.KeyValue >= 65 && e.KeyValue <= 90)
            //{
            //    setItemCmb();
            //}
            //else if (e.KeyValue >= 97 && e.KeyValue <= 122)
            //{
            //    setItemCmb();
            //}
        }


        //Used to append item names, id n value in single combobox
        //public void setItemCmb()
        //{
        //    DataSet ds = obj_bal_common.itemAC(cmb_item_name.Text, Login._userid);

        //    //adding first item as entered text in the combobox list
        //    DataRow dr = ds.Tables[0].NewRow();
        //    dr["item_name"] = cmb_item_name.Text;
        //    dr["value"] = "0_0";
        //    ds.Tables[0].Rows.InsertAt(dr, 0);

        //    cmb_item_name.DataSource = null;
        //    cmb_item_name.DataSource = ds.Tables[0];
        //    cmb_item_name.DisplayMember = "item_name";
        //    cmb_item_name.ValueMember = "value";

        //    //prvent cursor focus to move to the begining of text
        //    cmb_item_name.SelectionStart = cmb_item_name.Text.Length;
        //    cmb_item_name.SelectionLength = 0;
        //}

        private void cmb_item_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            //try
            //{
            //    txt_item_price.Text = cmb_item_name.SelectedValue.ToString().Split('_')[1];
            //}
            //catch (Exception)
            //{

            //}
        }

        private void calcItemTotal(object sender, EventArgs e)
        {
            decimal discount = 0;
            try
            {
                decimal total = Convert.ToDecimal(txt_item_price.Text) * Convert.ToDecimal(txt_item_quantity.Text);
                //try //if discount percent is not entered
                //{
                //    discount = total * Convert.ToDecimal(txt_item_disc_percent.Text) / 100;
                //}
                //catch (Exception)
                //{

                //    discount = 0;
                //}
                //txt_item_disc_amt.Text = discount.ToString();
                txt_item_total.Text = (total - discount).ToString();
            }
            catch (Exception)
            {

            }
        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog fu_img = new OpenFileDialog();
            fu_img.Filter = "Image Files(*.jpeg;*.bmp;*.png;*.jpg)|*.jpeg;*.bmp;*.png;*.jpg";
            if (fu_img.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txt_image.Text = fu_img.FileName;
                //string save_path = Application.StartupPath + "\\Files\\img_"+DateTime.Now.ToString();
            }
        }

        private void calcImageTotal(object sender, EventArgs e)
        {
            //decimal discount = 0;
            try
            {
                //decimal total = Convert.ToDecimal(txt_img_value.Text);
                //try //if discount percent is not entered
                //{
                //    discount = total * Convert.ToDecimal(txt_img_disc_percent.Text) / 100;
                //}
                //catch (Exception)
                //{

                //    discount = 0;
                //}
                //txt_img_disc_amt.Text = discount.ToString();
                //txt_img_total.Text = (total - discount).ToString();
            }
            catch (Exception)
            {

            }
        }

        private void btn_image_add_Click(object sender, EventArgs e)
        {
            int count1 = txt_img_total.Text.Trim().Split('.').Length - 1;
            if (count1 < 2)
            {
                TextBox[] controls = { txt_image, txt_img_total };
                if (obj_common.validateFields(controls))
                {
                    DataGridViewRow row = (DataGridViewRow)gdv_image.Rows[0].Clone();
                    //row.Cells["txt_gdv_item_id"].Value = mcc_items.SelectedItem.Value;
                    //row.Cells["txt_gdv_item_name"].Value = mcc_items.SelectedItem.Text;
                    row.Cells[0].Value = txt_image.Text.Trim();
                    //row.Cells[1].Value = txt_img_value.Text.Trim();
                    //row.Cells[2].Value = (txt_img_disc_percent.Text.Trim() == "") ? "0" : txt_img_disc_percent.Text.Trim();
                    //row.Cells[3].Value = (txt_img_disc_amt.Text.Trim() == "") ? "0" : txt_img_disc_amt.Text.Trim();
                    row.Cells[4].Value = txt_img_total.Text.Trim();

                    gdv_image.Rows.Add(row);

                    //clear add items textboxes
                    foreach (var control in controls)
                    {
                        control.Text = "";
                    }
                    calcFinal();
                }
            }
            else
            {
                MessageBox.Show("Cannot Enter more than one decimal!");
            }
        }

        private void gdv_image_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridView sendergdv = (DataGridView)sender;
                    DataGridViewRow row = sendergdv.Rows[e.RowIndex];
                    if (sendergdv.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex < sendergdv.Rows.Count - 1)
                    {
                        sendergdv.Rows.RemoveAt(e.RowIndex);
                    }
                    calcFinal();
                }
            }
            catch (Exception)
            {

            }
        }

        private void gdv_image_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            obj_common.gdvRowPostPaint(sender, e);
        }

        protected void calcFinal()
        {
            decimal final_total = 0;
            decimal final_discount = 0;
            decimal payment = 0;
            foreach (DataGridViewRow gdvr in gdv_item.Rows)
            {
                final_total += Convert.ToDecimal(gdvr.Cells["txt_gdv_item_price"].Value) * Convert.ToDecimal(gdvr.Cells["txt_gdv_item_quantity"].Value);
                //final_discount += Convert.ToDecimal(gdvr.Cells["txt_gdv_item_disc_amt"].Value);
            }
            foreach (DataGridViewRow gdvr in gdv_image.Rows)
            {
                final_total += Convert.ToDecimal(gdvr.Cells["txt_gdv_img_total"].Value);
                //final_discount += Convert.ToDecimal(gdvr.Cells["txt_gdv_img_disc_amt"].Value);
            }
            txt_total_amt.Text = final_total.ToString();
            //txt_total_disc.Text = final_discount.ToString();
            final_discount = (txt_total_disc.Text.Trim() == "") ? 0 : Convert.ToDecimal(txt_total_disc.Text);
            txt_net_amt.Text = (final_total - final_discount).ToString();

            try
            {
                payment = Convert.ToDecimal(txt_payment.Text);
            }
            catch (Exception)
            {

            }
            txt_pending.Text = (Convert.ToDecimal(txt_net_amt.Text) - payment).ToString();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                if (mcc_customer.SelectedItem.Value != null)
                {
                    if (gdv_item.Rows.Count > 1 || gdv_image.Rows.Count > 1)
                    {
                        int check1 = 0;
                        int check2 = 0;
                        obj_en_sale = new entity_sale();
                        obj_en_sale.customer_id = Convert.ToInt64(mcc_customer.SelectedItem.Value);
                        obj_en_sale.sale_time = Convert.ToDateTime(txt_date.Text);
                        obj_en_sale.due_date = Convert.ToDateTime(dtp_due_date.Value);
                        obj_en_sale.total_discount = (txt_total_disc.Text.Trim() == "") ? 0 : Convert.ToDecimal(txt_total_disc.Text);
                        obj_en_sale.total_amount = Convert.ToDecimal(txt_total_amt.Text);
                        obj_en_sale.payable_amount = Convert.ToDecimal(txt_net_amt.Text);
                        try
                        {
                            obj_en_sale.paid_amount = Convert.ToDecimal(txt_payment.Text);
                            obj_en_sale.pending_amount = Convert.ToDecimal(txt_pending.Text);
                        }
                        catch (Exception)
                        {
                            obj_en_sale.paid_amount = obj_en_sale.pending_amount = 0;
                        }

                        obj_en_sale.insert_user = Login._userid;
                        long saleid = obj_bal_sale.insertSale(obj_en_sale);

                        if (gdv_item.Rows.Count > 1)
                        {
                            DataTable item_dt = new DataTable("insert_item_tvp");
                            item_dt.Columns.Add("item_id");
                            item_dt.Columns.Add("item_name");
                            item_dt.Columns.Add("quantity");
                            item_dt.Columns.Add("price_per_unit");
                            item_dt.Columns.Add("total");
                            item_dt.Columns.Add("discount_percent");
                            item_dt.Columns.Add("discount_amount");
                            item_dt.Columns.Add("payable_amount");

                            foreach (DataGridViewRow gdvr in gdv_item.Rows)
                            {
                                try
                                {
                                    DataRow dr = item_dt.NewRow();
                                    dr["item_id"] = 0;                                                  // Convert.ToInt64(gdvr.Cells["txt_gdv_item_id"].Value);
                                    dr["item_name"] = gdvr.Cells["txt_gdv_item_name"].Value.ToString();
                                    dr["quantity"] = Convert.ToDecimal(gdvr.Cells["txt_gdv_item_quantity"].Value);
                                    dr["price_per_unit"] = Convert.ToDecimal(gdvr.Cells["txt_gdv_item_price"].Value);
                                    dr["total"] = Convert.ToDecimal(gdvr.Cells["txt_gdv_item_quantity"].Value) * Convert.ToDecimal(gdvr.Cells["txt_gdv_item_price"].Value);
                                    dr["discount_percent"] = 0;                                // Convert.ToDecimal(gdvr.Cells["txt_gdv_item_disc_percent"].Value);
                                    dr["discount_amount"] = 0;                                   //   Convert.ToDecimal(gdvr.Cells["txt_gdv_item_disc_amt"].Value);
                                    dr["payable_amount"] = Convert.ToDecimal(gdvr.Cells["txt_gdv_item_total"].Value);
                                    item_dt.Rows.Add(dr);
                                }
                                catch (Exception)
                                {

                                }

                            }
                            check1 = obj_bal_sale.insertItems(item_dt, saleid, Login._userid);
                        }

                        if (gdv_image.Rows.Count > 1)
                        {
                            string path = Application.StartupPath + "\\Files\\Images\\Sale\\" + txt_date.Value.ToString("yyyy MMMM") + "\\";
                            if (!Directory.Exists(path))
                            {
                                Directory.CreateDirectory(path);
                            }
                            int img_no = 0;
                            DataTable img_dt = new DataTable("insert_img_tvp");
                            img_dt.Columns.Add("file_name");
                            img_dt.Columns.Add("total");
                            img_dt.Columns.Add("discount_percent");
                            img_dt.Columns.Add("discount_amount");
                            img_dt.Columns.Add("payable_amount");
                            foreach (DataGridViewRow gdvr in gdv_image.Rows)
                            {

                                if (Convert.ToInt64(gdvr.Cells["txt_gdv_img_total"].Value) > 0)
                                {
                                    img_no++;
                                    DataRow dr = img_dt.NewRow();
                                    string[] file_name = gdvr.Cells["txt_gdv_img_image"].Value.ToString().Split('\\');
                                    string new_filename = saleid + "_" + DateTime.Now.ToString("dd-MM-yy-HH-mm-ss") + "_" + img_no + ".jpg";
                                    string new_filepath = path + new_filename;
                                    File.Copy(gdvr.Cells["txt_gdv_img_image"].Value.ToString(), new_filepath);
                                    dr["file_name"] = txt_date.Value.ToString("yyyy MMMM") + "\\" + new_filename;
                                    dr["total"] = Convert.ToDecimal(gdvr.Cells["txt_gdv_img_total"].Value);             //Convert.ToDecimal(gdvr.Cells["txt_gdv_img_value"].Value);
                                    dr["discount_percent"] = 0;                      // Convert.ToDecimal(gdvr.Cells["txt_gdv_img_disc_percent"].Value);
                                    dr["discount_amount"] = 0;                       // Convert.ToDecimal(gdvr.Cells["txt_gdv_img_disc_amt"].Value);
                                    dr["payable_amount"] = Convert.ToDecimal(gdvr.Cells["txt_gdv_img_total"].Value);
                                    img_dt.Rows.Add(dr);
                                }
                            }
                            check2 = obj_bal_sale.insertImages(img_dt, saleid, Login._userid);
                        }
                        if (saleid > 0 && (check1 > 0 || check2 > 0))
                        {
                            obj_common.ClearInputs(this.Controls);
                            //foreach (DataGridViewRow gdvr in gdv_item.Rows)
                            //{
                            //    gdv_item.Rows.Remove(gdvr);
                            //}
                            //foreach (DataGridViewRow gdvr in gdv_image.Rows)
                            //{
                            //    gdv_item.Rows.Remove(gdvr);
                            //}
                            txt_total_amt.Text = txt_total_disc.Text = txt_net_amt.Text = txt_payment.Text = txt_pending.Text = "";
                            gdv_item.Rows.Clear();
                            gdv_item.Refresh();
                            gdv_image.Rows.Clear();
                            gdv_image.Refresh();
                            mcc_customer.Clear();
                            lbl_alert.Text = "Sale Saved Successfully";
                        }
                        else
                        {
                            lbl_alert.Text = "Oops...Something went wrong!!";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please add an item first!");
                    }
                }
                else
                {
                    MessageBox.Show("Please select a customer first!");
                }
            }
            catch (Exception)
            {

            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            obj_common.ClearInputs(this.Controls);
            txt_total_amt.Text = txt_total_disc.Text = txt_net_amt.Text = txt_payment.Text = txt_pending.Text = "";
            gdv_item.Rows.Clear();
            gdv_item.Refresh();
            gdv_image.Rows.Clear();
            gdv_image.Refresh();
            mcc_customer.Clear();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void txt_payment_TextChanged(object sender, EventArgs e)
        {
            calcFinal();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            //this.Hide();

            //CustomerMaster obj_CustomerMaster = new CustomerMaster();
            //obj_CustomerMaster.Show();
        }

        private void btn_add_customer_Click(object sender, EventArgs e)
        {

            _reload_mcccustomer = true;
            CustomerMaster obj_CustomerMaster = new CustomerMaster();
            obj_CustomerMaster.MdiParent = this.MdiParent;
            obj_CustomerMaster.Show();
            this.Dispose();
        }

        private void txt_total_disc_TextChanged(object sender, EventArgs e)
        {
            calcFinal();
        }

        private void txt_item_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == (char)8 || e.KeyChar == (char)46);
        }

        private void txt_item_quantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == (char)8 || e.KeyChar == (char)46);
        }

        private void txt_img_total_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == (char)8 || e.KeyChar == (char)46);
        }
    }
}

