﻿namespace Image_Based_Billing
{
    partial class Purchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label13 = new System.Windows.Forms.Label();
            this.cmb_item_name = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txt_date = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_pending = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txt_payment = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_net_amt = new System.Windows.Forms.TextBox();
            this.txt_total_disc = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_total_amt = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btn_image_add = new System.Windows.Forms.Button();
            this.txt_img_total = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_browse = new System.Windows.Forms.Button();
            this.gdv_image = new System.Windows.Forms.DataGridView();
            this.txt_gdv_img_image = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_img_value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_img_disc_percent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_img_disc_amt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_img_total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_gdv_img_delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.gdv_item = new System.Windows.Forms.DataGridView();
            this.txt_gdv_item_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_disc_percent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_disc_amt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_gdv_item_delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_item_total = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_item_price = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.lbl_alert = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mcc_vendor = new VMultiColumnComboBox.MultiColumComboBox();
            this.btn_item_add = new System.Windows.Forms.Button();
            this.txt_image = new System.Windows.Forms.TextBox();
            this.txt_item_quantity = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_item)).BeginInit();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(944, 335);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 20);
            this.label13.TabIndex = 255;
            this.label13.Text = "Value";
            // 
            // cmb_item_name
            // 
            this.cmb_item_name.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmb_item_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_item_name.FormattingEnabled = true;
            this.cmb_item_name.Location = new System.Drawing.Point(70, 141);
            this.cmb_item_name.Name = "cmb_item_name";
            this.cmb_item_name.Size = new System.Drawing.Size(304, 24);
            this.cmb_item_name.TabIndex = 1;
            this.cmb_item_name.SelectedIndexChanged += new System.EventHandler(this.cmb_item_name_SelectedIndexChanged);
            this.cmb_item_name.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cmb_item_name_KeyUp);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Company Name",
            "Phone Number",
            "Address"});
            this.comboBox1.Location = new System.Drawing.Point(1165, 80);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(101, 21);
            this.comboBox1.TabIndex = 252;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txt_date
            // 
            this.txt_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_date.Location = new System.Drawing.Point(1037, 9);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(229, 26);
            this.txt_date.TabIndex = 250;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(943, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 20);
            this.label15.TabIndex = 251;
            this.label15.Text = "Date";
            // 
            // txt_pending
            // 
            this.txt_pending.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pending.Location = new System.Drawing.Point(839, 584);
            this.txt_pending.Name = "txt_pending";
            this.txt_pending.ReadOnly = true;
            this.txt_pending.Size = new System.Drawing.Size(155, 26);
            this.txt_pending.TabIndex = 249;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(835, 563);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(127, 20);
            this.label19.TabIndex = 248;
            this.label19.Text = "Pending Amount";
            // 
            // txt_payment
            // 
            this.txt_payment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_payment.Location = new System.Drawing.Point(646, 584);
            this.txt_payment.Name = "txt_payment";
            this.txt_payment.Size = new System.Drawing.Size(155, 26);
            this.txt_payment.TabIndex = 11;
            this.txt_payment.TextChanged += new System.EventHandler(this.txt_payment_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(642, 563);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 20);
            this.label18.TabIndex = 246;
            this.label18.Text = "Payment";
            // 
            // txt_net_amt
            // 
            this.txt_net_amt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_net_amt.Location = new System.Drawing.Point(458, 584);
            this.txt_net_amt.Name = "txt_net_amt";
            this.txt_net_amt.ReadOnly = true;
            this.txt_net_amt.Size = new System.Drawing.Size(155, 26);
            this.txt_net_amt.TabIndex = 245;
            // 
            // txt_total_disc
            // 
            this.txt_total_disc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total_disc.Location = new System.Drawing.Point(265, 584);
            this.txt_total_disc.Name = "txt_total_disc";
            this.txt_total_disc.Size = new System.Drawing.Size(155, 26);
            this.txt_total_disc.TabIndex = 10;
            this.txt_total_disc.TextChanged += new System.EventHandler(this.txt_total_disc_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(261, 563);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(144, 20);
            this.label14.TabIndex = 243;
            this.label14.Text = "Total Discount Amt";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(454, 563);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 20);
            this.label17.TabIndex = 242;
            this.label17.Text = "Net Amount";
            // 
            // txt_total_amt
            // 
            this.txt_total_amt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total_amt.Location = new System.Drawing.Point(70, 584);
            this.txt_total_amt.Name = "txt_total_amt";
            this.txt_total_amt.ReadOnly = true;
            this.txt_total_amt.Size = new System.Drawing.Size(155, 26);
            this.txt_total_amt.TabIndex = 240;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(66, 563);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(104, 20);
            this.label20.TabIndex = 241;
            this.label20.Text = "Total Amount";
            // 
            // btn_image_add
            // 
            this.btn_image_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_image_add.Location = new System.Drawing.Point(1197, 353);
            this.btn_image_add.Name = "btn_image_add";
            this.btn_image_add.Size = new System.Drawing.Size(69, 31);
            this.btn_image_add.TabIndex = 8;
            this.btn_image_add.Text = "Add";
            this.btn_image_add.UseVisualStyleBackColor = true;
            this.btn_image_add.Click += new System.EventHandler(this.btn_image_add_Click);
            // 
            // txt_img_total
            // 
            this.txt_img_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_img_total.Location = new System.Drawing.Point(947, 358);
            this.txt_img_total.Name = "txt_img_total";
            this.txt_img_total.Size = new System.Drawing.Size(184, 26);
            this.txt_img_total.TabIndex = 7;
            this.txt_img_total.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_img_total_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(943, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 20);
            this.label3.TabIndex = 228;
            this.label3.Text = "Total";
            // 
            // btn_browse
            // 
            this.btn_browse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_browse.Location = new System.Drawing.Point(69, 358);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(110, 26);
            this.btn_browse.TabIndex = 6;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = true;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // gdv_image
            // 
            this.gdv_image.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_image.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_image.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_img_image,
            this.txt_gdv_img_value,
            this.txt_gdv_img_disc_percent,
            this.txt_gdv_img_disc_amt,
            this.txt_gdv_img_total,
            this.btn_gdv_img_delete});
            this.gdv_image.Location = new System.Drawing.Point(70, 390);
            this.gdv_image.Name = "gdv_image";
            this.gdv_image.Size = new System.Drawing.Size(1196, 153);
            this.gdv_image.TabIndex = 9;
            this.gdv_image.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_image_CellContentClick);
            this.gdv_image.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_image_RowPostPaint);
            // 
            // txt_gdv_img_image
            // 
            this.txt_gdv_img_image.HeaderText = "Image";
            this.txt_gdv_img_image.Name = "txt_gdv_img_image";
            this.txt_gdv_img_image.ReadOnly = true;
            this.txt_gdv_img_image.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // txt_gdv_img_value
            // 
            this.txt_gdv_img_value.HeaderText = "Value";
            this.txt_gdv_img_value.Name = "txt_gdv_img_value";
            this.txt_gdv_img_value.ReadOnly = true;
            this.txt_gdv_img_value.Visible = false;
            // 
            // txt_gdv_img_disc_percent
            // 
            this.txt_gdv_img_disc_percent.HeaderText = "Discount %";
            this.txt_gdv_img_disc_percent.Name = "txt_gdv_img_disc_percent";
            this.txt_gdv_img_disc_percent.ReadOnly = true;
            this.txt_gdv_img_disc_percent.Visible = false;
            // 
            // txt_gdv_img_disc_amt
            // 
            this.txt_gdv_img_disc_amt.HeaderText = "Discount Amount";
            this.txt_gdv_img_disc_amt.Name = "txt_gdv_img_disc_amt";
            this.txt_gdv_img_disc_amt.ReadOnly = true;
            this.txt_gdv_img_disc_amt.Visible = false;
            // 
            // txt_gdv_img_total
            // 
            this.txt_gdv_img_total.HeaderText = "Total";
            this.txt_gdv_img_total.Name = "txt_gdv_img_total";
            this.txt_gdv_img_total.ReadOnly = true;
            // 
            // btn_gdv_img_delete
            // 
            this.btn_gdv_img_delete.HeaderText = "";
            this.btn_gdv_img_delete.Name = "btn_gdv_img_delete";
            this.btn_gdv_img_delete.Text = "Delete";
            this.btn_gdv_img_delete.UseColumnTextForButtonValue = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(261, 335);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 225;
            this.label6.Text = "Image";
            // 
            // gdv_item
            // 
            this.gdv_item.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_item.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_item.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_item_id,
            this.txt_gdv_item_name,
            this.txt_gdv_item_price,
            this.txt_gdv_item_quantity,
            this.txt_gdv_item_disc_percent,
            this.txt_gdv_item_disc_amt,
            this.txt_gdv_item_total,
            this.btn_gdv_item_delete});
            this.gdv_item.Location = new System.Drawing.Point(69, 171);
            this.gdv_item.Name = "gdv_item";
            this.gdv_item.Size = new System.Drawing.Size(1196, 141);
            this.gdv_item.TabIndex = 5;
            this.gdv_item.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_item_CellContentClick);
            this.gdv_item.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_item_RowPostPaint);
            // 
            // txt_gdv_item_id
            // 
            this.txt_gdv_item_id.HeaderText = "";
            this.txt_gdv_item_id.Name = "txt_gdv_item_id";
            this.txt_gdv_item_id.Visible = false;
            // 
            // txt_gdv_item_name
            // 
            this.txt_gdv_item_name.HeaderText = "Item Name";
            this.txt_gdv_item_name.Name = "txt_gdv_item_name";
            this.txt_gdv_item_name.ReadOnly = true;
            // 
            // txt_gdv_item_price
            // 
            this.txt_gdv_item_price.HeaderText = "Price";
            this.txt_gdv_item_price.Name = "txt_gdv_item_price";
            this.txt_gdv_item_price.ReadOnly = true;
            // 
            // txt_gdv_item_quantity
            // 
            this.txt_gdv_item_quantity.HeaderText = "Quantity";
            this.txt_gdv_item_quantity.Name = "txt_gdv_item_quantity";
            this.txt_gdv_item_quantity.ReadOnly = true;
            // 
            // txt_gdv_item_disc_percent
            // 
            this.txt_gdv_item_disc_percent.HeaderText = "Discount %";
            this.txt_gdv_item_disc_percent.Name = "txt_gdv_item_disc_percent";
            this.txt_gdv_item_disc_percent.ReadOnly = true;
            this.txt_gdv_item_disc_percent.Visible = false;
            // 
            // txt_gdv_item_disc_amt
            // 
            this.txt_gdv_item_disc_amt.HeaderText = "Discount Amount";
            this.txt_gdv_item_disc_amt.Name = "txt_gdv_item_disc_amt";
            this.txt_gdv_item_disc_amt.ReadOnly = true;
            this.txt_gdv_item_disc_amt.Visible = false;
            // 
            // txt_gdv_item_total
            // 
            this.txt_gdv_item_total.HeaderText = "Total";
            this.txt_gdv_item_total.Name = "txt_gdv_item_total";
            this.txt_gdv_item_total.ReadOnly = true;
            // 
            // btn_gdv_item_delete
            // 
            this.btn_gdv_item_delete.HeaderText = "";
            this.btn_gdv_item_delete.Name = "btn_gdv_item_delete";
            this.btn_gdv_item_delete.ReadOnly = true;
            this.btn_gdv_item_delete.Text = "Delete";
            this.btn_gdv_item_delete.UseColumnTextForButtonValue = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(66, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 20);
            this.label5.TabIndex = 221;
            this.label5.Text = "Item Name";
            // 
            // txt_item_total
            // 
            this.txt_item_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_item_total.Location = new System.Drawing.Point(947, 139);
            this.txt_item_total.Name = "txt_item_total";
            this.txt_item_total.ReadOnly = true;
            this.txt_item_total.Size = new System.Drawing.Size(184, 26);
            this.txt_item_total.TabIndex = 219;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(682, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 218;
            this.label2.Text = "Quantity";
            // 
            // txt_item_price
            // 
            this.txt_item_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_item_price.Location = new System.Drawing.Point(427, 139);
            this.txt_item_price.Name = "txt_item_price";
            this.txt_item_price.Size = new System.Drawing.Size(195, 26);
            this.txt_item_price.TabIndex = 2;
            this.txt_item_price.TextChanged += new System.EventHandler(this.calcItemTotal);
            this.txt_item_price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_item_price_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(423, 118);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 20);
            this.label16.TabIndex = 217;
            this.label16.Text = "Price";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(66, 84);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 20);
            this.label11.TabIndex = 215;
            this.label11.Text = "Vendor";
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(1191, 579);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 31);
            this.btn_reset.TabIndex = 13;
            this.btn_reset.Text = "Clear";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(1080, 579);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(75, 31);
            this.btn_save.TabIndex = 12;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // lbl_alert
            // 
            this.lbl_alert.AutoSize = true;
            this.lbl_alert.Location = new System.Drawing.Point(542, 22);
            this.lbl_alert.Name = "lbl_alert";
            this.lbl_alert.Size = new System.Drawing.Size(0, 13);
            this.lbl_alert.TabIndex = 214;
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(-12, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1368, 2);
            this.label10.TabIndex = 213;
            this.label10.Text = "  ";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 42);
            this.label1.TabIndex = 212;
            this.label1.Text = "Purchase Entry";
            // 
            // mcc_vendor
            // 
            this.mcc_vendor.ColumnWidth = null;
            this.mcc_vendor.DataSource = null;
            this.mcc_vendor.DisplayColumnNo = 1;
            this.mcc_vendor.DropDownHeight = 200;
            this.mcc_vendor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mcc_vendor.GridLines = VMultiColumnComboBox.GridLines.None;
            this.mcc_vendor.Location = new System.Drawing.Point(173, 80);
            this.mcc_vendor.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.mcc_vendor.Name = "mcc_vendor";
            this.mcc_vendor.SelectedItem = null;
            this.mcc_vendor.ShowHeader = false;
            this.mcc_vendor.Size = new System.Drawing.Size(958, 24);
            this.mcc_vendor.SourceDataHeader = null;
            this.mcc_vendor.SourceDataString = null;
            this.mcc_vendor.TabIndex = 0;
            this.mcc_vendor.ValueColumnNo = 0;
            // 
            // btn_item_add
            // 
            this.btn_item_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_item_add.Location = new System.Drawing.Point(1197, 134);
            this.btn_item_add.Name = "btn_item_add";
            this.btn_item_add.Size = new System.Drawing.Size(69, 31);
            this.btn_item_add.TabIndex = 4;
            this.btn_item_add.Text = "Add";
            this.btn_item_add.UseVisualStyleBackColor = true;
            this.btn_item_add.Click += new System.EventHandler(this.btn_item_add_Click);
            // 
            // txt_image
            // 
            this.txt_image.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_image.Location = new System.Drawing.Point(265, 358);
            this.txt_image.Name = "txt_image";
            this.txt_image.ReadOnly = true;
            this.txt_image.Size = new System.Drawing.Size(610, 26);
            this.txt_image.TabIndex = 224;
            this.txt_image.TextChanged += new System.EventHandler(this.calcImageTotal);
            // 
            // txt_item_quantity
            // 
            this.txt_item_quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_item_quantity.Location = new System.Drawing.Point(686, 139);
            this.txt_item_quantity.Name = "txt_item_quantity";
            this.txt_item_quantity.Size = new System.Drawing.Size(189, 26);
            this.txt_item_quantity.TabIndex = 3;
            this.txt_item_quantity.TextChanged += new System.EventHandler(this.calcItemTotal);
            this.txt_item_quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_item_quantity_KeyPress);
            // 
            // Purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 721);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cmb_item_name);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txt_pending);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txt_payment);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txt_net_amt);
            this.Controls.Add(this.txt_total_disc);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txt_total_amt);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.btn_image_add);
            this.Controls.Add(this.txt_img_total);
            this.Controls.Add(this.txt_item_quantity);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_browse);
            this.Controls.Add(this.gdv_image);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gdv_item);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_item_total);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_item_price);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.lbl_alert);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mcc_vendor);
            this.Controls.Add(this.btn_item_add);
            this.Controls.Add(this.txt_image);
            this.Name = "Purchase";
            this.Text = "Purchase";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.gdv_image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_item)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmb_item_name;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DateTimePicker txt_date;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_pending;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt_payment;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_net_amt;
        private System.Windows.Forms.TextBox txt_total_disc;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_total_amt;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btn_image_add;
        private System.Windows.Forms.TextBox txt_img_total;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.DataGridView gdv_image;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView gdv_item;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_item_total;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_item_price;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label lbl_alert;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private VMultiColumnComboBox.MultiColumComboBox mcc_vendor;
        private System.Windows.Forms.Button btn_item_add;
        private System.Windows.Forms.TextBox txt_image;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_image;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_value;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_disc_percent;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_disc_amt;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_total;
        private System.Windows.Forms.DataGridViewButtonColumn btn_gdv_img_delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_price;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_disc_percent;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_disc_amt;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_total;
        private System.Windows.Forms.DataGridViewButtonColumn btn_gdv_item_delete;
        private System.Windows.Forms.TextBox txt_item_quantity;
    }
}