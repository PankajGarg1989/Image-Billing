﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bal;
using System.Diagnostics;

namespace Image_Based_Billing
{
    public partial class SaleDetailDialog : Form
    {
        public static string _sale_item_image = "";
        bal_sale_report obj_bal_sale_report = new bal_sale_report();
        common obj_common = new common();
        public SaleDetailDialog()
        {
            InitializeComponent();
            DataSet ds = obj_bal_sale_report.getSaleDetails(SaleReport._saleid, Login._userid);
            gdv_sale_detail.AutoGenerateColumns = false;
            gdv_sale_detail.DataSource = ds.Tables[0];
            gdv_sale_detail.Columns["sale_item_id"].DataPropertyName = "id";
            gdv_sale_detail.Columns["sale_item_name"].DataPropertyName = "item";
            gdv_sale_detail.Columns["sale_item_quantity"].DataPropertyName = "quantity";
            gdv_sale_detail.Columns["sale_item_price"].DataPropertyName = "price";
            gdv_sale_detail.Columns["sale_item_total"].DataPropertyName = "value";
        }

        private void gdv_sale_detail_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            obj_common.gdvRowPostPaint(sender, e);
        }

        private void gdv_sale_detail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridView sender_gdv = (DataGridView)sender;
                DataGridViewRow gdvr = sender_gdv.Rows[e.RowIndex];

                if (e.ColumnIndex == 1)
                {
                    if (gdvr.Cells["sale_item_quantity"].Value.ToString() == "" && gdvr.Cells["sale_item_price"].Value.ToString() == "")
                    {
                        _sale_item_image = Application.StartupPath + "\\Files\\Images\\Sale\\" + gdvr.Cells["sale_item_name"].Value.ToString();
                        Process.Start(_sale_item_image);

                    }

                }
            }
        }
    }
}

