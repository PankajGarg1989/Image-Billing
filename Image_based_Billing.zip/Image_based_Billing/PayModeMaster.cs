﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using entity;
using bal;
namespace Image_Based_Billing
{
    public partial class PayModeMaster : Form
    {
        entity_m_pay_mode obj_en_m_paymode;
        bal_pay_mode obj_bal_pay_mode = new bal_pay_mode();
        common obj_common = new common();

        public PayModeMaster()
        {
            InitializeComponent();
            bindGdv();
            lbl_alert.Text = ""; 

        }

        private void bindGdv()
        {
            try
            {
                gdv_paymodes.Columns.Remove(gdv_paymodes.Columns["btn_status"]);

            }
            catch (Exception)
            {

            }
            DataSet ds = obj_bal_pay_mode.loadPayModes(Login._userid);

            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            btn.Name = "btn_status";
            btn.HeaderText = "";
            btn.DataPropertyName = "status";
            gdv_paymodes.Columns.Add(btn);

            gdv_paymodes.AutoGenerateColumns = false;
            gdv_paymodes.DataSource = ds.Tables[0];
            gdv_paymodes.Columns[0].DataPropertyName = "id";
            gdv_paymodes.Columns[1].DataPropertyName = "p_mode_name"; 

        }

        private void gdv_taxes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = gdv_paymodes.Rows[e.RowIndex];
                if (e.ColumnIndex == 2)
                {
                    obj_en_m_paymode = new entity_m_pay_mode();
                    obj_en_m_paymode.id = Convert.ToInt64(row.Cells["txt_gdv_paymode_id"].Value);
                    int i = obj_bal_pay_mode.changePayModeStatus(obj_en_m_paymode);
                    if (i > 0)
                    {
                        lbl_alert.Text = "Operation completed Successfully";
                        lbl_alert.Visible = true;
                        bindGdv();
                    }
                    else
                    {
                        lbl_alert.Text = "Oops... Something went wrong";
                        lbl_alert.Visible = true;

                    }
                }
            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (txt_name.Text.Trim() != "Save")
            {
                obj_en_m_paymode = new entity_m_pay_mode();
                obj_en_m_paymode.p_mode_name = txt_name.Text.Trim();
                obj_en_m_paymode.insert_user = Login._userid;
                int i = obj_bal_pay_mode.savePayModes(obj_en_m_paymode);
                if (i > 0)
                {
                    lbl_alert.Text = "Saved Successfully";
                    lbl_alert.Visible = true;
                    obj_common.ClearInputs(Parent.Controls);
                    bindGdv();
                    btn_save.Text = "Save";
                }
                else
                {
                    lbl_alert.Text = "Oops.. Something went wrong";
                    lbl_alert.Visible = true;
                }

            }
        }

        private void PayModeMaster_Load(object sender, EventArgs e)
        {

        }
    }
}
