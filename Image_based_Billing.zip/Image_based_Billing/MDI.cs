﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceProcess;

namespace Image_Based_Billing
{
    public partial class mainform : Form
    {

        public mainform()
        {
            InitializeComponent();
        }

        public void closePrevForms()
        {

            foreach (Form child in MdiChildren)
            {
                child.Close();
            }

        }
        public void DisposeAllButThis(Form form)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (frm.GetType() == form.GetType()
                    && frm != form)
                {
                    frm.Close();
                }
            }
        }
        private void companyInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {

            closePrevForms();

            CompanyInfoMaster obj_companyinfo = new CompanyInfoMaster();
            obj_companyinfo.TopLevel = false;
            obj_companyinfo.Show();
            obj_companyinfo.MdiParent = this;
        }

        private void partyMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();

            CustomerMaster obj_CustomerMaster = new CustomerMaster();
            obj_CustomerMaster.TopLevel = false;
            obj_CustomerMaster.Show();
            obj_CustomerMaster.MdiParent = this;
        }

        private void statusStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void masterToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void taxMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            TaxMaster obj = new TaxMaster();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void jobEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            Purchase obj = new Purchase();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void sessionMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();

            SessionMaster obj_SessionMaster = new SessionMaster();
            obj_SessionMaster.TopLevel = false;
            obj_SessionMaster.Show();
            obj_SessionMaster.MdiParent = this;
        }

        private void invoiceEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            Sale obj = new Sale();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void paymentEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();

            CustomerPaymentEntry obj_PaymentEntry = new CustomerPaymentEntry();
            obj_PaymentEntry.TopLevel = false;
            obj_PaymentEntry.Show();
            obj_PaymentEntry.MdiParent = this;
        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {

            System.Diagnostics.Process p = System.Diagnostics.Process.Start("calc.exe");

        }

        private void MDI_Load(object sender, EventArgs e)
        {

        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            SaleReport obj = new SaleReport();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;

        }

        private void backupDBToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void jobRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();

        }

        private void printInvoicesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void mainform_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void vendorMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            VendorMaster obj = new VendorMaster();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceController obj_service = new ServiceController("MSSQL$SQLEXPRESS");
                obj_service.Stop();
            }
            catch { }
            Environment.Exit(0);

        }

        private void paymentModeMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            PayModeMaster obj = new PayModeMaster();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void itemMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            ItemMaster obj = new ItemMaster();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void purchaseReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            PurchaseReport obj = new PurchaseReport();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void vendorPaymentEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            VendorPaymentEntry obj = new VendorPaymentEntry();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void customerPaymentReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            CustomerPaymentReport obj = new CustomerPaymentReport();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void vendorPaymentReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            VendorPaymentReport obj = new VendorPaymentReport();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void saleReturnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            SaleReturn obj = new SaleReturn();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void saleReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            SaleReturnReport obj = new SaleReturnReport();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }

        private void completeCustomerAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closePrevForms();
            CompleteCustomerAccount obj = new CompleteCustomerAccount();
            obj.TopLevel = false;
            obj.Show();
            obj.MdiParent = this;
        }
    }
}
