﻿namespace Image_Based_Billing
{
    partial class CustomerPaymentEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_header_id = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gdv_pendings = new System.Windows.Forms.DataGridView();
            this.btn_search = new System.Windows.Forms.Button();
            this.lbl_alert = new System.Windows.Forms.Label();
            this.mcc_customer = new VMultiColumnComboBox.MultiColumComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dtp_to_date = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.dtp_from_date = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_pay = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_gdv_sale_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_cust_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_customer_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_phone_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_sale_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_final_payable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_pending = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_payment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_ref_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_pendings)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(-1, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1308, 2);
            this.label10.TabIndex = 77;
            this.label10.Text = "  ";
            // 
            // lbl_header_id
            // 
            this.lbl_header_id.AutoSize = true;
            this.lbl_header_id.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbl_header_id.Location = new System.Drawing.Point(81, 145);
            this.lbl_header_id.Name = "lbl_header_id";
            this.lbl_header_id.Size = new System.Drawing.Size(0, 13);
            this.lbl_header_id.TabIndex = 79;
            this.lbl_header_id.Visible = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(411, 46);
            this.label1.TabIndex = 68;
            this.label1.Text = "Customer Payment Entry";
            // 
            // gdv_pendings
            // 
            this.gdv_pendings.AllowUserToAddRows = false;
            this.gdv_pendings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_pendings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_pendings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_sale_id,
            this.txt_gdv_cust_id,
            this.txt_gdv_customer_name,
            this.txt_gdv_phone_no,
            this.txt_gdv_sale_date,
            this.txt_gdv_final_payable,
            this.txt_gdv_pending,
            this.txt_gdv_payment,
            this.txt_gdv_ref_no});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gdv_pendings.DefaultCellStyle = dataGridViewCellStyle1;
            this.gdv_pendings.Location = new System.Drawing.Point(84, 254);
            this.gdv_pendings.Name = "gdv_pendings";
            this.gdv_pendings.Size = new System.Drawing.Size(1104, 329);
            this.gdv_pendings.TabIndex = 4;
            this.gdv_pendings.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_pendings_CellEndEdit);
            this.gdv_pendings.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView1_RowPostPaint);
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(574, 194);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 33);
            this.btn_search.TabIndex = 3;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // lbl_alert
            // 
            this.lbl_alert.AutoSize = true;
            this.lbl_alert.Location = new System.Drawing.Point(1049, 238);
            this.lbl_alert.Name = "lbl_alert";
            this.lbl_alert.Size = new System.Drawing.Size(0, 13);
            this.lbl_alert.TabIndex = 139;
            // 
            // mcc_customer
            // 
            this.mcc_customer.ColumnWidth = null;
            this.mcc_customer.DataSource = null;
            this.mcc_customer.DisplayColumnNo = 1;
            this.mcc_customer.DropDownHeight = 200;
            this.mcc_customer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mcc_customer.GridLines = VMultiColumnComboBox.GridLines.None;
            this.mcc_customer.Location = new System.Drawing.Point(188, 103);
            this.mcc_customer.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.mcc_customer.Name = "mcc_customer";
            this.mcc_customer.SelectedItem = null;
            this.mcc_customer.ShowHeader = false;
            this.mcc_customer.Size = new System.Drawing.Size(829, 24);
            this.mcc_customer.SourceDataHeader = null;
            this.mcc_customer.SourceDataString = null;
            this.mcc_customer.TabIndex = 0;
            this.mcc_customer.ValueColumnNo = 0;
            this.mcc_customer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.focusNext);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Company Name",
            "Phone Number",
            "Address"});
            this.comboBox1.Location = new System.Drawing.Point(1026, 104);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(101, 21);
            this.comboBox1.TabIndex = 137;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(80, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 138;
            this.label2.Text = "Customer";
            // 
            // dtp_to_date
            // 
            this.dtp_to_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_to_date.Location = new System.Drawing.Point(717, 148);
            this.dtp_to_date.Name = "dtp_to_date";
            this.dtp_to_date.Size = new System.Drawing.Size(300, 26);
            this.dtp_to_date.TabIndex = 2;
            this.dtp_to_date.KeyDown += new System.Windows.Forms.KeyEventHandler(this.focusNext);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(596, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 20);
            this.label3.TabIndex = 154;
            this.label3.Text = "To";
            // 
            // dtp_from_date
            // 
            this.dtp_from_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_from_date.Location = new System.Drawing.Point(188, 147);
            this.dtp_from_date.Name = "dtp_from_date";
            this.dtp_from_date.Size = new System.Drawing.Size(300, 26);
            this.dtp_from_date.TabIndex = 1;
            this.dtp_from_date.Value = new System.DateTime(2017, 4, 1, 0, 0, 0, 0);
            this.dtp_from_date.KeyDown += new System.Windows.Forms.KeyEventHandler(this.focusNext);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(80, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 20);
            this.label4.TabIndex = 157;
            this.label4.Text = "Sale Date";
            // 
            // btn_pay
            // 
            this.btn_pay.Location = new System.Drawing.Point(1052, 204);
            this.btn_pay.Name = "btn_pay";
            this.btn_pay.Size = new System.Drawing.Size(75, 23);
            this.btn_pay.TabIndex = 5;
            this.btn_pay.Text = "Pay";
            this.btn_pay.UseVisualStyleBackColor = true;
            this.btn_pay.Click += new System.EventHandler(this.btn_pay_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dateTimePicker1.Location = new System.Drawing.Point(914, 26);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 23);
            this.dateTimePicker1.TabIndex = 158;
            // 
            // txt_gdv_sale_id
            // 
            this.txt_gdv_sale_id.HeaderText = "";
            this.txt_gdv_sale_id.Name = "txt_gdv_sale_id";
            this.txt_gdv_sale_id.ReadOnly = true;
            this.txt_gdv_sale_id.Visible = false;
            // 
            // txt_gdv_cust_id
            // 
            this.txt_gdv_cust_id.HeaderText = "";
            this.txt_gdv_cust_id.Name = "txt_gdv_cust_id";
            this.txt_gdv_cust_id.ReadOnly = true;
            this.txt_gdv_cust_id.Visible = false;
            // 
            // txt_gdv_customer_name
            // 
            this.txt_gdv_customer_name.FillWeight = 74.08508F;
            this.txt_gdv_customer_name.HeaderText = "Customer Name";
            this.txt_gdv_customer_name.Name = "txt_gdv_customer_name";
            this.txt_gdv_customer_name.ReadOnly = true;
            // 
            // txt_gdv_phone_no
            // 
            this.txt_gdv_phone_no.FillWeight = 70.09747F;
            this.txt_gdv_phone_no.HeaderText = "Phone No.";
            this.txt_gdv_phone_no.Name = "txt_gdv_phone_no";
            this.txt_gdv_phone_no.ReadOnly = true;
            // 
            // txt_gdv_sale_date
            // 
            this.txt_gdv_sale_date.FillWeight = 79.05183F;
            this.txt_gdv_sale_date.HeaderText = "Sale Date";
            this.txt_gdv_sale_date.Name = "txt_gdv_sale_date";
            this.txt_gdv_sale_date.ReadOnly = true;
            // 
            // txt_gdv_final_payable
            // 
            this.txt_gdv_final_payable.FillWeight = 80.35353F;
            this.txt_gdv_final_payable.HeaderText = "Payable";
            this.txt_gdv_final_payable.Name = "txt_gdv_final_payable";
            this.txt_gdv_final_payable.ReadOnly = true;
            // 
            // txt_gdv_pending
            // 
            this.txt_gdv_pending.FillWeight = 142.3258F;
            this.txt_gdv_pending.HeaderText = "Pending Amount";
            this.txt_gdv_pending.Name = "txt_gdv_pending";
            this.txt_gdv_pending.ReadOnly = true;
            // 
            // txt_gdv_payment
            // 
            this.txt_gdv_payment.FillWeight = 100.6332F;
            this.txt_gdv_payment.HeaderText = "Payment";
            this.txt_gdv_payment.Name = "txt_gdv_payment";
            // 
            // txt_gdv_ref_no
            // 
            this.txt_gdv_ref_no.FillWeight = 253.4531F;
            this.txt_gdv_ref_no.HeaderText = "Reference No.";
            this.txt_gdv_ref_no.Name = "txt_gdv_ref_no";
            // 
            // CustomerPaymentEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 721);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btn_pay);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtp_to_date);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtp_from_date);
            this.Controls.Add(this.lbl_alert);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.mcc_customer);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.gdv_pendings);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lbl_header_id);
            this.Controls.Add(this.label1);
            this.Name = "CustomerPaymentEntry";
            this.Text = "PaymentEntry";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.gdv_pendings)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_header_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView gdv_pendings;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Label lbl_alert;
        private VMultiColumnComboBox.MultiColumComboBox mcc_customer;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtp_to_date;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtp_from_date;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_pay;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_sale_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_cust_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_customer_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_phone_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_sale_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_final_payable;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_pending;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_payment;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_ref_no;
    }
}