﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bal;
using entity;
using System.Diagnostics;


namespace Image_Based_Billing
{
    public partial class CustomerPaymentReport : Form
    {
        common obj_common = new common();
        Report obj_en_Report;
        bal_customer_pay_report obj_bal_cust_pay_report = new bal_customer_pay_report();
        string _filepath = "";
        public CustomerPaymentReport()
        {
            InitializeComponent();

            comboBox1.SelectedIndex = 0;
            mcc_customer.Clear();
            mcc_customer.SourceDataString = new string[4] { "cust_company", "cust_phone", "cust_address", "id" };
            mcc_customer.ColumnWidth = new string[4] { "300", "150", "500", "0" };
            mcc_customer.DataSource = new bal_customer().loadCustomer(Login._userid).Tables[0];
            mcc_customer.DisplayColumnNo = 0;
            mcc_customer.ValueColumnNo = 3;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            obj_en_Report = new Report();

            getGridviewData();
        }

        private void getGridviewData()
        {
            try
            {
                obj_en_Report.cust_id = Convert.ToInt64(mcc_customer.SelectedItem.Value);

            }
            catch (Exception)
            {
                obj_en_Report.cust_id = 0;
            }
            obj_en_Report.from_date = Convert.ToDateTime(dtp_from_date.Text);
            obj_en_Report.to_date = Convert.ToDateTime(dtp_to_date.Text);
            obj_en_Report.insert_user = Login._userid;
            DataSet ds = obj_bal_cust_pay_report.getGridviewData(obj_en_Report);
            if (ds.Tables[0].Rows.Count > 0)
            {

                DataRow temp_dr = ds.Tables[0].NewRow();
                temp_dr["cust_phone"] = "GROSS AMOUNTS";
                temp_dr["final_payable"] = ds.Tables[1].Rows[0]["final_payable"].ToString();
                temp_dr["payment"] = ds.Tables[1].Rows[0]["payment"].ToString();
                ds.Tables[0].Rows.Add(temp_dr);


                gdv_report.AutoGenerateColumns = false;
                gdv_report.DataSource = ds.Tables[0];
                gdv_report.Columns["txt_gdv_pay_id"].DataPropertyName = "id";
                gdv_report.Columns["txt_gdv_cust_id"].DataPropertyName = "cust_id";
                gdv_report.Columns["txt_gdv_customer"].DataPropertyName = "cust_company";
                gdv_report.Columns["txt_gdv_cust_phone"].DataPropertyName = "cust_phone";
                gdv_report.Columns["txt_gdv_sale_date"].DataPropertyName = "sale_date";
                gdv_report.Columns["txt_gdv_payable_amount"].DataPropertyName = "final_payable";
                gdv_report.Columns["txt_gdv_payment"].DataPropertyName = "payment";
                gdv_report.Columns["txt_gdv_ref_no"].DataPropertyName = "reference_no";
                gdv_report.Columns["txt_gdv_pay_date"].DataPropertyName = "pay_date";
                btn_excel_export.Visible = true;
            }
        }

        private void gdv_report_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void gdv_report_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            obj_common.gdvRowPostPaint(sender, e);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            mcc_customer.DisplayColumnNo = comboBox1.SelectedIndex;
        }

        private void btn_excel_export_Click(object sender, EventArgs e)
        {
            DataTable pay_report_dt = getDataForExcel();
            Excel.ExcelUtlity obj_excel_util = new Excel.ExcelUtlity();
            _filepath = Application.StartupPath + "\\Files\\Reports\\Cust_Pay_" + DateTime.Now.ToString("dd-MMM-yyyy HH-mm") + ".xlsx";
            obj_excel_util.WriteDataTableToExcel(pay_report_dt, "pay_report_dtay Report", _filepath, "");
            MessageBox.Show("Successfully Exported");
            Process obj_open = new Process();
            obj_open.StartInfo.FileName = _filepath;
            obj_open.Start();
        }

        private DataTable getDataForExcel()
        {
            DataTable gridview_dt = new DataTable();
            gridview_dt.Columns.Add("Customer");
            gridview_dt.Columns.Add("Phone");
            gridview_dt.Columns.Add("Sale_Date");
            gridview_dt.Columns.Add("Payable_Amount");
            gridview_dt.Columns.Add("Payment_Received");
            gridview_dt.Columns.Add("Payment_Date");
            gridview_dt.Columns.Add("Reference_No.");


            foreach (DataGridViewRow dr in gdv_report.Rows)
            {
                DataRow row = gridview_dt.NewRow();

                for (int i = 0; i < 7; i++)
                {
                    row[i] = dr.Cells[i + 2].Value.ToString();
                }
                gridview_dt.Rows.Add(row);
            }
            return gridview_dt;

        }
    }
}
