﻿namespace Image_Based_Billing
{
    partial class TaxMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.gdv_taxes = new System.Windows.Forms.DataGridView();
            this.txt_gdv_tax_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_tax_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_tax_value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_edit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btn_delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_tax_name = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_tax_id = new System.Windows.Forms.Label();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.lbl_alert = new System.Windows.Forms.Label();
            this.txt_tax_value = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_taxes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_tax_value)).BeginInit();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(869, 428);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 13);
            this.label11.TabIndex = 77;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(-12, 72);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1308, 2);
            this.label10.TabIndex = 76;
            this.label10.Text = "  ";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // gdv_taxes
            // 
            this.gdv_taxes.AllowUserToAddRows = false;
            this.gdv_taxes.AllowUserToDeleteRows = false;
            this.gdv_taxes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdv_taxes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gdv_taxes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_taxes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_tax_id,
            this.txt_gdv_tax_name,
            this.txt_gdv_tax_value,
            this.btn_edit,
            this.btn_delete});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gdv_taxes.DefaultCellStyle = dataGridViewCellStyle2;
            this.gdv_taxes.Location = new System.Drawing.Point(185, 344);
            this.gdv_taxes.Name = "gdv_taxes";
            this.gdv_taxes.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdv_taxes.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gdv_taxes.Size = new System.Drawing.Size(951, 178);
            this.gdv_taxes.TabIndex = 4;
            this.gdv_taxes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_taxes_CellContentClick);
            this.gdv_taxes.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_taxes_RowPostPaint);
            // 
            // txt_gdv_tax_id
            // 
            this.txt_gdv_tax_id.HeaderText = "";
            this.txt_gdv_tax_id.Name = "txt_gdv_tax_id";
            this.txt_gdv_tax_id.ReadOnly = true;
            this.txt_gdv_tax_id.Visible = false;
            // 
            // txt_gdv_tax_name
            // 
            this.txt_gdv_tax_name.HeaderText = "Tax Name";
            this.txt_gdv_tax_name.Name = "txt_gdv_tax_name";
            this.txt_gdv_tax_name.ReadOnly = true;
            // 
            // txt_gdv_tax_value
            // 
            this.txt_gdv_tax_value.HeaderText = "Tax Value (%)";
            this.txt_gdv_tax_value.Name = "txt_gdv_tax_value";
            this.txt_gdv_tax_value.ReadOnly = true;
            // 
            // btn_edit
            // 
            this.btn_edit.HeaderText = "";
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.ReadOnly = true;
            this.btn_edit.Text = "Edit";
            this.btn_edit.UseColumnTextForButtonValue = true;
            // 
            // btn_delete
            // 
            this.btn_delete.HeaderText = "";
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.ReadOnly = true;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseColumnTextForButtonValue = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(477, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 20);
            this.label5.TabIndex = 70;
            this.label5.Text = "Tax Value";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txt_tax_name
            // 
            this.txt_tax_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tax_name.Location = new System.Drawing.Point(618, 131);
            this.txt_tax_name.Name = "txt_tax_name";
            this.txt_tax_name.Size = new System.Drawing.Size(287, 26);
            this.txt_tax_name.TabIndex = 0;
            this.txt_tax_name.TextChanged += new System.EventHandler(this.txt_tax_name_TextChanged);
            this.txt_tax_name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.focusNext);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(476, 140);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 20);
            this.label9.TabIndex = 68;
            this.label9.Text = "Tax Name";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 77);
            this.label1.TabIndex = 67;
            this.label1.Text = "Tax Master";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_tax_id
            // 
            this.lbl_tax_id.AutoSize = true;
            this.lbl_tax_id.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbl_tax_id.Location = new System.Drawing.Point(61, 154);
            this.lbl_tax_id.Name = "lbl_tax_id";
            this.lbl_tax_id.Size = new System.Drawing.Size(0, 13);
            this.lbl_tax_id.TabIndex = 78;
            this.lbl_tax_id.Visible = false;
            this.lbl_tax_id.Click += new System.EventHandler(this.lbl_tax_id_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(1088, 26);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 31);
            this.btn_reset.TabIndex = 3;
            this.btn_reset.Text = "Clear";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(979, 26);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(75, 31);
            this.btn_save.TabIndex = 2;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // lbl_alert
            // 
            this.lbl_alert.AutoSize = true;
            this.lbl_alert.Location = new System.Drawing.Point(549, 36);
            this.lbl_alert.Name = "lbl_alert";
            this.lbl_alert.Size = new System.Drawing.Size(0, 13);
            this.lbl_alert.TabIndex = 135;
            this.lbl_alert.Click += new System.EventHandler(this.lbl_alert_Click);
            // 
            // txt_tax_value
            // 
            this.txt_tax_value.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tax_value.Location = new System.Drawing.Point(618, 207);
            this.txt_tax_value.Name = "txt_tax_value";
            this.txt_tax_value.Size = new System.Drawing.Size(287, 26);
            this.txt_tax_value.TabIndex = 1;
            this.txt_tax_value.ValueChanged += new System.EventHandler(this.txt_tax_value_ValueChanged);
            this.txt_tax_value.Enter += new System.EventHandler(this.txt_Enter);
            this.txt_tax_value.KeyDown += new System.Windows.Forms.KeyEventHandler(this.focusNext);
            // 
            // TaxMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 561);
            this.Controls.Add(this.txt_tax_value);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.lbl_alert);
            this.Controls.Add(this.lbl_tax_id);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.gdv_taxes);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_tax_name);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TaxMaster";
            this.Text = "TaxMaster";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.TaxMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gdv_taxes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_tax_value)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView gdv_taxes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_tax_name;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_tax_id;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label lbl_alert;
        private System.Windows.Forms.NumericUpDown txt_tax_value;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_tax_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_tax_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_tax_value;
        private System.Windows.Forms.DataGridViewButtonColumn btn_edit;
        private System.Windows.Forms.DataGridViewButtonColumn btn_delete;

    }
}