﻿namespace Image_Based_Billing
{
    partial class CompleteCustomerAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label4 = new System.Windows.Forms.Label();
            this.dtp_to_date = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dtp_from_date = new System.Windows.Forms.DateTimePicker();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_excel_export = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.gdv_report = new System.Windows.Forms.DataGridView();
            this.txt_gdv_sale_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_cust_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_cust_phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_cust_address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_sale_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_total_amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_payment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_pending = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_due_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_report)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(89, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 20);
            this.label4.TabIndex = 757;
            this.label4.Text = "Sale Date";
            // 
            // dtp_to_date
            // 
            this.dtp_to_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_to_date.Location = new System.Drawing.Point(610, 89);
            this.dtp_to_date.Name = "dtp_to_date";
            this.dtp_to_date.Size = new System.Drawing.Size(300, 26);
            this.dtp_to_date.TabIndex = 753;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(550, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 20);
            this.label1.TabIndex = 756;
            this.label1.Text = "To";
            // 
            // dtp_from_date
            // 
            this.dtp_from_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_from_date.Location = new System.Drawing.Point(197, 90);
            this.dtp_from_date.Name = "dtp_from_date";
            this.dtp_from_date.Size = new System.Drawing.Size(300, 26);
            this.dtp_from_date.TabIndex = 752;
            this.dtp_from_date.Value = new System.DateTime(2017, 4, 1, 0, 0, 0, 0);
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(502, 160);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 31);
            this.btn_search.TabIndex = 754;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_excel_export
            // 
            this.btn_excel_export.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_excel_export.Location = new System.Drawing.Point(600, 160);
            this.btn_excel_export.Name = "btn_excel_export";
            this.btn_excel_export.Size = new System.Drawing.Size(123, 31);
            this.btn_excel_export.TabIndex = 755;
            this.btn_excel_export.Text = "Export to Excel";
            this.btn_excel_export.UseVisualStyleBackColor = true;
            this.btn_excel_export.Visible = false;
            this.btn_excel_export.Click += new System.EventHandler(this.btn_excel_export_Click);
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(-3, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1378, 2);
            this.label10.TabIndex = 759;
            this.label10.Text = "  ";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(307, 42);
            this.label3.TabIndex = 758;
            this.label3.Text = "Customer Accounts";
            // 
            // gdv_report
            // 
            this.gdv_report.AllowUserToAddRows = false;
            this.gdv_report.AllowUserToDeleteRows = false;
            this.gdv_report.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_report.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gdv_report.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdv_report.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gdv_report.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_report.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_sale_id,
            this.txt_gdv_cust_id,
            this.txt_gdv_customer,
            this.txt_gdv_cust_phone,
            this.txt_gdv_cust_address,
            this.txt_gdv_sale_date,
            this.txt_gdv_total_amount,
            this.txt_gdv_payment,
            this.txt_gdv_pending,
            this.txt_gdv_due_date});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gdv_report.DefaultCellStyle = dataGridViewCellStyle2;
            this.gdv_report.Location = new System.Drawing.Point(62, 225);
            this.gdv_report.Name = "gdv_report";
            this.gdv_report.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdv_report.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gdv_report.Size = new System.Drawing.Size(1133, 392);
            this.gdv_report.TabIndex = 760;
            this.gdv_report.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_report_CellContentClick);
            // 
            // txt_gdv_sale_id
            // 
            this.txt_gdv_sale_id.HeaderText = "";
            this.txt_gdv_sale_id.Name = "txt_gdv_sale_id";
            this.txt_gdv_sale_id.ReadOnly = true;
            this.txt_gdv_sale_id.Visible = false;
            // 
            // txt_gdv_cust_id
            // 
            this.txt_gdv_cust_id.HeaderText = "";
            this.txt_gdv_cust_id.Name = "txt_gdv_cust_id";
            this.txt_gdv_cust_id.ReadOnly = true;
            this.txt_gdv_cust_id.Visible = false;
            // 
            // txt_gdv_customer
            // 
            this.txt_gdv_customer.HeaderText = "Customer";
            this.txt_gdv_customer.Name = "txt_gdv_customer";
            this.txt_gdv_customer.ReadOnly = true;
            // 
            // txt_gdv_cust_phone
            // 
            this.txt_gdv_cust_phone.HeaderText = "Customer Phone";
            this.txt_gdv_cust_phone.Name = "txt_gdv_cust_phone";
            this.txt_gdv_cust_phone.ReadOnly = true;
            // 
            // txt_gdv_cust_address
            // 
            this.txt_gdv_cust_address.HeaderText = "Address";
            this.txt_gdv_cust_address.Name = "txt_gdv_cust_address";
            this.txt_gdv_cust_address.ReadOnly = true;
            // 
            // txt_gdv_sale_date
            // 
            this.txt_gdv_sale_date.HeaderText = "Sale Date";
            this.txt_gdv_sale_date.Name = "txt_gdv_sale_date";
            this.txt_gdv_sale_date.ReadOnly = true;
            // 
            // txt_gdv_total_amount
            // 
            this.txt_gdv_total_amount.HeaderText = "Total Amount";
            this.txt_gdv_total_amount.Name = "txt_gdv_total_amount";
            this.txt_gdv_total_amount.ReadOnly = true;
            // 
            // txt_gdv_payment
            // 
            this.txt_gdv_payment.HeaderText = "Payment Received";
            this.txt_gdv_payment.Name = "txt_gdv_payment";
            this.txt_gdv_payment.ReadOnly = true;
            // 
            // txt_gdv_pending
            // 
            this.txt_gdv_pending.HeaderText = "Pending Amount";
            this.txt_gdv_pending.Name = "txt_gdv_pending";
            this.txt_gdv_pending.ReadOnly = true;
            // 
            // txt_gdv_due_date
            // 
            this.txt_gdv_due_date.HeaderText = "Due Date";
            this.txt_gdv_due_date.Name = "txt_gdv_due_date";
            this.txt_gdv_due_date.ReadOnly = true;
            // 
            // CompleteCustomerAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 721);
            this.Controls.Add(this.gdv_report);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtp_to_date);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtp_from_date);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_excel_export);
            this.Name = "CompleteCustomerAccount";
            this.Text = "CompleteCustomerAccount";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.gdv_report)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtp_to_date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtp_from_date;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_excel_export;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView gdv_report;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_sale_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_cust_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_cust_phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_cust_address;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_sale_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_total_amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_payment;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_pending;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_due_date;
    }
}