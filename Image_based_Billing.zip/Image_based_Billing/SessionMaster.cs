﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bal;
using entity;

namespace Image_Based_Billing
{
   
    public partial class SessionMaster : Form
    {
        bal_session obj_bal_session = new bal_session();
        public SessionMaster()
        {
            InitializeComponent();
            loadSessions();
        }

        private void loadSessions()
        {
            DataTable dt = obj_bal_session.readSessions();
            cmb_sessions.DataSource = dt;
            cmb_sessions.DisplayMember = "session";
            cmb_sessions.ValueMember = "id";
            DataRow[] active_session = dt.Select("isactive = True");
            cmb_sessions.SelectedValue = active_session[0]["id"];
        }


        private void btn_save_Click(object sender, EventArgs e)
        {
            int session_id = Convert.ToInt32(cmb_sessions.SelectedValue);
            int i = obj_bal_session.updateSessions(session_id);
            if (i > 0)
            {
                lbl_alert.Visible = true;
                lbl_alert.Text = "Successfully Updated!";
                loadSessions();
            }
            else
            {
                lbl_alert.Visible = true;
                lbl_alert.Text = "Something went wrong!";
            }
        }
    }
}
