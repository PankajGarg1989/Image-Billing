﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using entity;
using bal;

namespace Image_Based_Billing
{
    public partial class CustomerMaster : Form
    {
        entity_m_customer obj_entity_m_customer;
        bal_customer obj_bal_customer = new bal_customer();
        common obj_common = new common();
        public CustomerMaster()
        {
            InitializeComponent();
            bindCustomer();
            lbl_alert.Visible = false;
        }
        protected void bindCustomer()
        {
            try
            {
                gdv_customers.Columns.Remove(gdv_customers.Columns["btn_status"]);
            }
            catch (Exception)
            {

            }
            DataSet ds = obj_bal_customer.loadCustomer(Login._userid);
            DataView dv = new DataView(ds.Tables[0]);

            DataTable dt = dv.ToTable(false, "cust_company", "cust_address", "cust_phone", "cust_mobile1", "cust_mobile2", "cust_email", "id", "status");

            DataGridViewButtonColumn btn1 = new DataGridViewButtonColumn();
            btn1.HeaderText = "";
            btn1.Name = "btn_status";
            btn1.DataPropertyName = "status";
            gdv_customers.Columns.Add(btn1);

            gdv_customers.DataSource = dt;
            gdv_customers.Columns["btn_edit"].DisplayIndex = 8;
            gdv_customers.Columns["btn_status"].DisplayIndex = 7;
            gdv_customers.Columns["btn_delete"].DisplayIndex = 9;
            gdv_customers.Columns["id"].Visible = false;


        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void CustomerMaster_Load(object sender, EventArgs e)
        {

        }

        private void focusNext(object sender, KeyPressEventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {


            int i = 0;
            if (btn_save.Text.ToLower() == "save")
            {
                i = saveCustomer();

            }
            else
            {
                i = updateCustomer();
            }
            if (i > 0)
            {
                lbl_customer_id.Text = "0";
                btn_save.Text = "Save";
                lbl_alert.Text = "Saved Successfully";
                lbl_alert.Visible = true;
                try
                {
                    txt_comp_name.Text = txt_address.Text = txt_phone.Text = txt_mobile1.Text = txt_mobile2.Text = txt_email.Text = "";

                    obj_common.ClearInputs(Parent.Controls);
                }
                catch { }
                bindCustomer();
                //new Sale().mccCustomerLoad();

                if (Sale._reload_mcccustomer)
                {
                    Sale obj = new Sale();
                    obj.MdiParent = this.MdiParent;
                    obj.Show();
                    
                    Sale._reload_mcccustomer = false;
                   
                    this.Dispose();
                }
            }
            else
            {
                lbl_alert.Text = "Customer with same name already exists!";
                lbl_alert.Visible = true;
            }
        }

        private int updateCustomer()
        {
            obj_entity_m_customer = new entity_m_customer();
            obj_entity_m_customer.cust_company = txt_comp_name.Text.Trim();
            //obj_entity_m_customer.cust_name = txt_customer_name.Text.Trim();
            obj_entity_m_customer.cust_address = txt_address.Text.Trim();
            obj_entity_m_customer.cust_phone = txt_phone.Text.Trim();
            obj_entity_m_customer.cust_mobile1 = txt_mobile1.Text.Trim();
            obj_entity_m_customer.cust_mobile2 = txt_mobile2.Text.Trim();
            obj_entity_m_customer.cust_email = txt_email.Text.Trim();
            //obj_entity_m_customer.cust_gst = txt_gstno.Text.Trim();
            //obj_entity_m_customer.cust_pan = txt_panno.Text.Trim();
            //obj_entity_m_customer.cust_aadhar = txt_aadharno.Text.Trim();
            obj_entity_m_customer.id = Convert.ToInt64(lbl_customer_id.Text);
            obj_entity_m_customer.modify_user = Login._userid;

            int i = obj_bal_customer.editCustomer(obj_entity_m_customer);
            return i;
        }

        private int saveCustomer()
        {
            obj_entity_m_customer = new entity_m_customer();
            obj_entity_m_customer.cust_company = txt_comp_name.Text.Trim();
            //obj_entity_m_customer.cust_name = txt_customer_name.Text.Trim();
            obj_entity_m_customer.cust_address = txt_address.Text.Trim();
            obj_entity_m_customer.cust_phone = txt_phone.Text.Trim();
            obj_entity_m_customer.cust_mobile1 = txt_mobile1.Text.Trim();
            obj_entity_m_customer.cust_mobile2 = txt_mobile2.Text.Trim();
            obj_entity_m_customer.cust_email = txt_email.Text.Trim();
            //obj_entity_m_customer.cust_gst = txt_gstno.Text.Trim();
            //obj_entity_m_customer.cust_pan = txt_panno.Text.Trim();
            //obj_entity_m_customer.cust_aadhar = txt_aadharno.Text.Trim();
            obj_entity_m_customer.insert_user = Login._userid;

            int i = obj_bal_customer.saveCustomer(obj_entity_m_customer);
            return i;
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            try
            {
                txt_comp_name.Text = txt_address.Text = txt_phone.Text = txt_mobile1.Text = txt_mobile2.Text = txt_email.Text = "";
                obj_common.ClearInputs(Parent.Controls);
            }
            catch
            {

            }
            lbl_alert.Text = "";
            btn_save.Text = "Save";
        }

        private void gdv_customers_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                // right alignment might actually make more sense for numbers
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);

        }

        private void gdv_customers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var senderGrid = (DataGridView)sender;
                DataGridViewRow row = gdv_customers.Rows[e.RowIndex];
                lbl_customer_id.Text = row.Cells["id"].Value.ToString();
                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    if (e.ColumnIndex == 0)
                    {
                        txt_comp_name.Text = row.Cells["cust_company"].Value.ToString();
                        //txt_customer_name.Text = row.Cells["cust_name"].Value.ToString();
                        txt_address.Text = row.Cells["cust_address"].Value.ToString();
                        txt_phone.Text = row.Cells["cust_phone"].Value.ToString();
                        txt_email.Text = row.Cells["cust_email"].Value.ToString();
                        txt_mobile1.Text = row.Cells["cust_mobile1"].Value.ToString();
                        txt_mobile2.Text = row.Cells["cust_mobile2"].Value.ToString();

                        //txt_gstno.Text = row.Cells["cust_gst"].Value.ToString();
                        //txt_panno.Text = row.Cells["cust_pan"].Value.ToString();
                        //txt_aadharno.Text = row.Cells["cust_aadhar"].Value.ToString();
                        btn_save.Text = "Update";
                    }
                    else if (e.ColumnIndex == gdv_customers.Columns.IndexOf(gdv_customers.Columns["btn_delete"]))
                    {
                        DialogResult = MessageBox.Show("Are you sure you want to delete this record? All Related data will be wiped out!! ", "Conditional", MessageBoxButtons.YesNo);
                        if (DialogResult == DialogResult.Yes)
                        {
                            obj_entity_m_customer = new entity_m_customer();
                            obj_entity_m_customer.id = Convert.ToInt64(lbl_customer_id.Text);
                            int i = obj_bal_customer.deleteCustomer(obj_entity_m_customer);
                            if (i > 0)
                            {
                                lbl_alert.Text = "Operation Completed Successfully";
                                lbl_alert.Visible = true;
                                bindCustomer();
                            }
                            else
                            {
                                lbl_alert.Text = "Oops... Something went wrong";
                                lbl_alert.Visible = true;

                            }
                        }
                    }
                    else
                    {
                        obj_entity_m_customer = new entity_m_customer();
                        obj_entity_m_customer.id = Convert.ToInt64(lbl_customer_id.Text);
                        int i = obj_bal_customer.changeCustomerStatus(obj_entity_m_customer);
                        if (i > 0)
                        {
                            lbl_alert.Text = "Operation Completed Successfully";
                            lbl_alert.Visible = true;
                            bindCustomer();
                        }
                        else
                        {
                            lbl_alert.Text = "Oops... Something went wrong";
                            lbl_alert.Visible = true;

                        }
                    }
                }
            }
        }

        public void focusNext(object sender, KeyEventArgs e)
        {

            if (e.KeyValue == 13)
            {
                Control ctrl = (Control)sender;

                this.SelectNextControl(ctrl, true, true, true, true);
                e.SuppressKeyPress = true;
            }
            else
            {

            }

        }

        private void txt_comp_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_customer_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_phone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_address_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_email_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_gstno_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //public override void focusNext(object sender, KeyEventArgs e ){
        //    if (e.KeyValue == 13)
        //    {
        //        Control ctrl = (Control)sender;

        //        this.SelectNextControl(ctrl, true, true, true, true);
        //        e.SuppressKeyPress = true;
        //    }
        //    else
        //    {

        //    }
        //}
    }
}
