﻿namespace Image_Based_Billing
{
    partial class mainform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.companyInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.partyMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendorMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jobEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invoiceEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saleReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendorPaymentEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saleReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendorPaymentReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerPaymentReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.calculatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.completeCustomerAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 679);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1284, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            this.statusStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip_ItemClicked);
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterToolStripMenuItem,
            this.newToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.toolsToolStripMenuItem1,
            this.logOutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1284, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.companyInformationToolStripMenuItem,
            this.partyMasterToolStripMenuItem,
            this.vendorMasterToolStripMenuItem,
            this.itemMasterToolStripMenuItem});
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.masterToolStripMenuItem.Text = "Master";
            this.masterToolStripMenuItem.Click += new System.EventHandler(this.masterToolStripMenuItem_Click);
            // 
            // companyInformationToolStripMenuItem
            // 
            this.companyInformationToolStripMenuItem.Name = "companyInformationToolStripMenuItem";
            this.companyInformationToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.companyInformationToolStripMenuItem.Text = "Company Information";
            this.companyInformationToolStripMenuItem.Click += new System.EventHandler(this.companyInformationToolStripMenuItem_Click);
            // 
            // partyMasterToolStripMenuItem
            // 
            this.partyMasterToolStripMenuItem.Name = "partyMasterToolStripMenuItem";
            this.partyMasterToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.partyMasterToolStripMenuItem.Text = "Customer Master";
            this.partyMasterToolStripMenuItem.Click += new System.EventHandler(this.partyMasterToolStripMenuItem_Click);
            // 
            // vendorMasterToolStripMenuItem
            // 
            this.vendorMasterToolStripMenuItem.Name = "vendorMasterToolStripMenuItem";
            this.vendorMasterToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.vendorMasterToolStripMenuItem.Text = "Vendor Master";
            this.vendorMasterToolStripMenuItem.Click += new System.EventHandler(this.vendorMasterToolStripMenuItem_Click);
            // 
            // itemMasterToolStripMenuItem
            // 
            this.itemMasterToolStripMenuItem.Name = "itemMasterToolStripMenuItem";
            this.itemMasterToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.itemMasterToolStripMenuItem.Text = "Item Master";
            this.itemMasterToolStripMenuItem.Click += new System.EventHandler(this.itemMasterToolStripMenuItem_Click);
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jobEntryToolStripMenuItem,
            this.invoiceEntryToolStripMenuItem,
            this.saleReturnToolStripMenuItem,
            this.vendorPaymentEntryToolStripMenuItem,
            this.paymentEntryToolStripMenuItem});
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.newToolStripMenuItem.Text = "New";
            // 
            // jobEntryToolStripMenuItem
            // 
            this.jobEntryToolStripMenuItem.Name = "jobEntryToolStripMenuItem";
            this.jobEntryToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.jobEntryToolStripMenuItem.Text = "Purchase";
            this.jobEntryToolStripMenuItem.Click += new System.EventHandler(this.jobEntryToolStripMenuItem_Click);
            // 
            // invoiceEntryToolStripMenuItem
            // 
            this.invoiceEntryToolStripMenuItem.Name = "invoiceEntryToolStripMenuItem";
            this.invoiceEntryToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.invoiceEntryToolStripMenuItem.Text = "Sale";
            this.invoiceEntryToolStripMenuItem.Click += new System.EventHandler(this.invoiceEntryToolStripMenuItem_Click);
            // 
            // saleReturnToolStripMenuItem
            // 
            this.saleReturnToolStripMenuItem.Name = "saleReturnToolStripMenuItem";
            this.saleReturnToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.saleReturnToolStripMenuItem.Text = "Sale Return";
            this.saleReturnToolStripMenuItem.Click += new System.EventHandler(this.saleReturnToolStripMenuItem_Click);
            // 
            // vendorPaymentEntryToolStripMenuItem
            // 
            this.vendorPaymentEntryToolStripMenuItem.Name = "vendorPaymentEntryToolStripMenuItem";
            this.vendorPaymentEntryToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.vendorPaymentEntryToolStripMenuItem.Text = "Vendor Payment Entry";
            this.vendorPaymentEntryToolStripMenuItem.Click += new System.EventHandler(this.vendorPaymentEntryToolStripMenuItem_Click);
            // 
            // paymentEntryToolStripMenuItem
            // 
            this.paymentEntryToolStripMenuItem.Name = "paymentEntryToolStripMenuItem";
            this.paymentEntryToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.paymentEntryToolStripMenuItem.Text = "Customer Payment Entry";
            this.paymentEntryToolStripMenuItem.Click += new System.EventHandler(this.paymentEntryToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.purchaseReportToolStripMenuItem,
            this.paymentToolStripMenuItem,
            this.saleReportToolStripMenuItem,
            this.vendorPaymentReportToolStripMenuItem,
            this.customerPaymentReportToolStripMenuItem,
            this.completeCustomerAccountToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.toolsToolStripMenuItem.Text = "Reports";
            this.toolsToolStripMenuItem.Click += new System.EventHandler(this.toolsToolStripMenuItem_Click);
            // 
            // purchaseReportToolStripMenuItem
            // 
            this.purchaseReportToolStripMenuItem.Name = "purchaseReportToolStripMenuItem";
            this.purchaseReportToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.purchaseReportToolStripMenuItem.Text = "Purchase Report";
            this.purchaseReportToolStripMenuItem.Click += new System.EventHandler(this.purchaseReportToolStripMenuItem_Click);
            // 
            // paymentToolStripMenuItem
            // 
            this.paymentToolStripMenuItem.Name = "paymentToolStripMenuItem";
            this.paymentToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.paymentToolStripMenuItem.Text = "Sale Report";
            this.paymentToolStripMenuItem.Click += new System.EventHandler(this.paymentToolStripMenuItem_Click);
            // 
            // saleReportToolStripMenuItem
            // 
            this.saleReportToolStripMenuItem.Name = "saleReportToolStripMenuItem";
            this.saleReportToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.saleReportToolStripMenuItem.Text = "Sale Return Report";
            this.saleReportToolStripMenuItem.Click += new System.EventHandler(this.saleReportToolStripMenuItem_Click);
            // 
            // vendorPaymentReportToolStripMenuItem
            // 
            this.vendorPaymentReportToolStripMenuItem.Name = "vendorPaymentReportToolStripMenuItem";
            this.vendorPaymentReportToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.vendorPaymentReportToolStripMenuItem.Text = "Vendor Payment Report";
            this.vendorPaymentReportToolStripMenuItem.Click += new System.EventHandler(this.vendorPaymentReportToolStripMenuItem_Click);
            // 
            // customerPaymentReportToolStripMenuItem
            // 
            this.customerPaymentReportToolStripMenuItem.Name = "customerPaymentReportToolStripMenuItem";
            this.customerPaymentReportToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.customerPaymentReportToolStripMenuItem.Text = "Customer Payment Report";
            this.customerPaymentReportToolStripMenuItem.Click += new System.EventHandler(this.customerPaymentReportToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem1
            // 
            this.toolsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculatorToolStripMenuItem});
            this.toolsToolStripMenuItem1.Name = "toolsToolStripMenuItem1";
            this.toolsToolStripMenuItem1.Size = new System.Drawing.Size(47, 20);
            this.toolsToolStripMenuItem1.Text = "Tools";
            // 
            // calculatorToolStripMenuItem
            // 
            this.calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            this.calculatorToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.calculatorToolStripMenuItem.Text = "Calculator";
            this.calculatorToolStripMenuItem.Click += new System.EventHandler(this.calculatorToolStripMenuItem_Click);
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // completeCustomerAccountToolStripMenuItem
            // 
            this.completeCustomerAccountToolStripMenuItem.Name = "completeCustomerAccountToolStripMenuItem";
            this.completeCustomerAccountToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.completeCustomerAccountToolStripMenuItem.Text = "Complete Customer Account";
            this.completeCustomerAccountToolStripMenuItem.Click += new System.EventHandler(this.completeCustomerAccountToolStripMenuItem_Click);
            // 
            // mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 701);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.Name = "mainform";
            this.Text = "Base Billing Application ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mainform_FormClosing);
            this.Load += new System.EventHandler(this.MDI_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companyInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem partyMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendorMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jobEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invoiceEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem calculatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendorPaymentEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerPaymentReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendorPaymentReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saleReturnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saleReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem completeCustomerAccountToolStripMenuItem;
    }
}



