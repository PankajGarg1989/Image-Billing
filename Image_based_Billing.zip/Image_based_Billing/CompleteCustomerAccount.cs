﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bal;
using entity;
using System.Diagnostics;

namespace Image_Based_Billing
{
    public partial class CompleteCustomerAccount : Form
    {
        common obj_common = new common();
        Report obj_en_Report;
        bal_sale_report obj_bal_sale_report = new bal_sale_report();
        string _filepath = "";

        DataTable cust_pay_dt;
        public CompleteCustomerAccount()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            obj_en_Report = new Report();
            cust_pay_dt = new DataTable();

            DataSet ds = obj_bal_sale_report.getCustomersId();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                getGridviewData(Convert.ToInt64( dr["customer_id"]));
            }

            if (cust_pay_dt.Rows.Count > 0)
            {

                gdv_report.AutoGenerateColumns = false;
                gdv_report.DataSource = cust_pay_dt;
                gdv_report.Columns["txt_gdv_sale_id"].DataPropertyName = "id";
                gdv_report.Columns["txt_gdv_cust_id"].DataPropertyName = "customer_id";
                gdv_report.Columns["txt_gdv_customer"].DataPropertyName = "cust_company";
                gdv_report.Columns["txt_gdv_cust_phone"].DataPropertyName = "cust_phone";
                gdv_report.Columns["txt_gdv_cust_address"].DataPropertyName = "cust_address";
                gdv_report.Columns["txt_gdv_sale_date"].DataPropertyName = "sale_time";
                //gdv_report.Columns["txt_gdv_discount"].DataPropertyName = "total_discount";
                gdv_report.Columns["txt_gdv_total_amount"].DataPropertyName = "payable_amount";
                //gdv_report.Columns["txt_gdv_payable_amount"].DataPropertyName = "payable_amount";
                gdv_report.Columns["txt_gdv_payment"].DataPropertyName = "payment";
                gdv_report.Columns["txt_gdv_pending"].DataPropertyName = "pending";
                gdv_report.Columns["txt_gdv_due_date"].DataPropertyName = "due_date";
                btn_excel_export.Visible = true;

                paintCells();
            }
        }

        private void paintCells()
        {
            if (gdv_report.Rows.Count > 0)
            {
                foreach (DataGridViewRow gdvr in gdv_report.Rows)
                {
                    try
                    {
                        if (25000 <= Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value))
                        {
                            gdvr.Cells["txt_gdv_pending"].Style.BackColor = Color.Red;
                        }
                        if (10000 < Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value) && Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value) < 25000)
                        {
                            gdvr.Cells["txt_gdv_pending"].Style.BackColor = Color.Yellow;
                        }
                        if (5000 < Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value) && Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value) < 10000)
                        {
                            gdvr.Cells["txt_gdv_pending"].Style.BackColor = Color.GreenYellow;
                        }

                        if (gdvr.Cells["txt_gdv_due_date"].Value != DBNull.Value)
                        {
                            if (Convert.ToDateTime(gdvr.Cells["txt_gdv_due_date"].Value) <= DateTime.Now)
                            {
                                gdvr.Cells["txt_gdv_due_date"].Style.BackColor = Color.LightGray;
                            }
                        }
                    }
                    catch
                    {

                    }
                }
            }


        }
        private void getGridviewData(long cust_id)
        {
           
            obj_en_Report.from_date = Convert.ToDateTime(dtp_from_date.Text);
            obj_en_Report.to_date = Convert.ToDateTime(dtp_to_date.Text);
            obj_en_Report.insert_user = Login._userid;
            obj_en_Report.cust_id = cust_id;
            DataSet ds = obj_bal_sale_report.getGridviewData(obj_en_Report);

            if (ds.Tables[0].Rows.Count > 0)
            {
                cust_pay_dt.Merge(ds.Tables[0]);

            }

            DataRow dr = cust_pay_dt.NewRow();
            dr["sale_time"] = "Gross Values:";
            dr["payable_amount"] = ds.Tables[1].Rows[0]["final_payable"];
            dr["payment"] = ds.Tables[1].Rows[0]["payment"];
            dr["pending"] = ds.Tables[1].Rows[0]["pending"];
            cust_pay_dt.Rows.Add(dr);
        }

        private void btn_excel_export_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable cust_report_dt = getDataForExcel();
                Excel.ExcelUtlity obj_excel_util = new Excel.ExcelUtlity();
                _filepath = Application.StartupPath + "\\Files\\Reports\\CustomerAccount_" + DateTime.Now.ToString("dd-MMM-yyyy HH-mm") + ".xlsx";
                obj_excel_util.WriteDataTableToExcel(cust_report_dt, "Customer Accounts", _filepath, "");
                MessageBox.Show("Successfully Exported");
                Process obj_open = new Process();
                obj_open.StartInfo.FileName = _filepath;
                obj_open.Start();
            }
            catch
            {

            }
        }

        private DataTable getDataForExcel()
        {

            DataTable gridview_dt = new DataTable();
            gridview_dt.Columns.Add("Customer");
            gridview_dt.Columns.Add("Phone");
            gridview_dt.Columns.Add("Address");
            gridview_dt.Columns.Add("Sale_Date");
            gridview_dt.Columns.Add("Total_Amount");
            gridview_dt.Columns.Add("Payment_Received");
            gridview_dt.Columns.Add("Pending Amount");
            gridview_dt.Columns.Add("Due_Date");

            foreach (DataGridViewRow dr in gdv_report.Rows)
            {
                DataRow row = gridview_dt.NewRow();

                for (int i = 0; i < 8; i++)
                {
                    row[i] = dr.Cells[i + 2].Value.ToString();
                }
                gridview_dt.Rows.Add(row);
            }
            return gridview_dt;
        }

        private void gdv_report_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
