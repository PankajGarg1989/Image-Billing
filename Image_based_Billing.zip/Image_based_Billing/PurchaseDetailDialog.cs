﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bal;
using System.Diagnostics;

namespace Image_Based_Billing
{
    public partial class PurchaseDetailDialog : Form
    {
        public static string _purchase_item_image = "";
        bal_purchase_report obj_bal_purchase_report = new bal_purchase_report();
        common obj_common = new common();
        public PurchaseDetailDialog()
        {
            InitializeComponent();
            DataSet ds = obj_bal_purchase_report.getPurchaseDetails(PurchaseReport._purchaseid, Login._userid);
            gdv_purchase_detail.AutoGenerateColumns = false;
            gdv_purchase_detail.DataSource = ds.Tables[0];
            gdv_purchase_detail.Columns["purchase_item_id"].DataPropertyName = "id";
            gdv_purchase_detail.Columns["purchase_item_name"].DataPropertyName = "item";
            gdv_purchase_detail.Columns["purchase_item_quantity"].DataPropertyName = "quantity";
            gdv_purchase_detail.Columns["purchase_item_price"].DataPropertyName = "price";
            gdv_purchase_detail.Columns["purchase_item_total"].DataPropertyName = "value";
        }

        private void gdv_purchase_detail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridView sender_gdv = (DataGridView)sender;
                DataGridViewRow gdvr = sender_gdv.Rows[e.RowIndex];

                if (e.ColumnIndex == 1)
                {
                    if (gdvr.Cells["purchase_item_quantity"].Value.ToString() == "" && gdvr.Cells["purchase_item_price"].Value.ToString() == "")
                    {
                        _purchase_item_image = Application.StartupPath + "\\Files\\Images\\Purchase\\" + gdvr.Cells["purchase_item_name"].Value.ToString();
                        Process.Start(_purchase_item_image);
                    }
                }
            }
        }

        private void gdv_purchase_detail_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            obj_common.gdvRowPostPaint(sender, e);
        }
    }
}
