﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bal;
using entity;

namespace Image_Based_Billing
{
    public partial class VendorPaymentEntry : Form
    {
        common obj_common = new common();
        bal_vendor_payment_entry obj_bal_vendor_payment_entry = new bal_vendor_payment_entry();
        Report obj_en_Report;
        public VendorPaymentEntry()
        {
            InitializeComponent();

            comboBox1.SelectedIndex = 0;
            mcc_vendor.Clear();
            mcc_vendor.SourceDataString = new string[4] { "vend_company", "vend_phone", "vend_address", "id" };
            mcc_vendor.ColumnWidth = new string[4] { "300", "150", "500", "0" };
            mcc_vendor.DataSource = new bal_vendor().loadVendor(Login._userid).Tables[0];
            mcc_vendor.DisplayColumnNo = 0;
            mcc_vendor.ValueColumnNo = 3;
        }

        
        private void gdv_pendings_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            obj_common.gdvRowPostPaint(sender, e);
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            obj_en_Report = new Report();
            lbl_alert.Text = "";

            getGridviewData();
        }

        private void getGridviewData()
        {
            try
            {
                obj_en_Report.vend_id = Convert.ToInt64(mcc_vendor.SelectedItem.Value);
            }
            catch (Exception)
            {
                obj_en_Report.vend_id = 0;
            }
            obj_en_Report.from_date = Convert.ToDateTime(dtp_from_date.Text);
            obj_en_Report.to_date = Convert.ToDateTime(dtp_to_date.Text);
            obj_en_Report.insert_user = Login._userid;
            DataSet ds = obj_bal_vendor_payment_entry.getPending(obj_en_Report);

            if (ds.Tables[0].Rows.Count > 0)
            {
                //adding gross amount row in table[0]
                DataRow temp_dr = ds.Tables[0].NewRow();

                temp_dr["payable_amount"] = ds.Tables[1].Rows[0]["final_payable"];
                temp_dr["pending"] = ds.Tables[1].Rows[0]["pending"];
                ds.Tables[0].Rows.Add(temp_dr);


                gdv_pendings.AutoGenerateColumns = false;
                gdv_pendings.DataSource = ds.Tables[0];
                gdv_pendings.Columns[0].DataPropertyName = "purchase_id";
                gdv_pendings.Columns[1].DataPropertyName = "vend_id";
                gdv_pendings.Columns[2].DataPropertyName = "vend_company";
                gdv_pendings.Columns[3].DataPropertyName = "vend_phone";
                gdv_pendings.Columns[4].DataPropertyName = "purchase_time";
                gdv_pendings.Columns[5].DataPropertyName = "payable_amount";
                gdv_pendings.Columns[6].DataPropertyName = "pending";

                //gdv_pendings.Columns["txt_gdv_vend_id"].DataPropertyName = "cust_id";

                gdv_pendings.Rows[gdv_pendings.Rows.Count - 1].Cells["txt_gdv_purchase_date"].Value = "GROSS AMOUNTS";
                gdv_pendings.Rows[gdv_pendings.Rows.Count - 1].Cells["txt_gdv_ref_no"].ReadOnly = true;
                gdv_pendings.Rows[gdv_pendings.Rows.Count - 1].Cells["txt_gdv_payment"].ReadOnly = true;
            }
            else
            {
                gdv_pendings.DataSource = new DataTable();
                MessageBox.Show("No Data found for selected parameters!");
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            mcc_vendor.DisplayColumnNo = comboBox1.SelectedIndex;
        }

        private void gdv_pendings_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            decimal total_pay = 0;
            try
            {
                foreach (DataGridViewRow dgr in gdv_pendings.Rows)
                {
                    if (dgr.Cells["txt_gdv_payment"].Value != null && dgr.Cells["txt_gdv_purchase_date"].Value.ToString() != "GROSS AMOUNTS")
                    {
                        total_pay += Convert.ToDecimal(dgr.Cells["txt_gdv_payment"].Value);
                    }
                }
                gdv_pendings.Rows[gdv_pendings.Rows.Count - 1].Cells["txt_gdv_payment"].Value = total_pay;

            }
            catch (Exception)
            {

            }
        }

        private void btn_pay_Click(object sender, EventArgs e)
        {
            DataTable payment_dt = new DataTable("vend_pay_insert_tvp");
            payment_dt.Columns.Add("purchase_id");
            payment_dt.Columns.Add("vend_id");
            payment_dt.Columns.Add("payment");
            payment_dt.Columns.Add("reference_no");


            try
            {
                foreach (DataGridViewRow dgr in gdv_pendings.Rows)
                {
                    if (dgr.Cells["txt_gdv_payment"].Value != null && dgr.Cells["txt_gdv_purchase_date"].Value.ToString() != "GROSS AMOUNTS")
                    {
                        DataRow dr = payment_dt.NewRow();
                        dr["purchase_id"] = Convert.ToInt64(dgr.Cells["txt_gdv_purchase_id"].Value);
                        dr["vend_id"] = Convert.ToInt64(dgr.Cells["txt_gdv_vend_id"].Value);
                        dr["payment"] = Convert.ToDecimal(dgr.Cells["txt_gdv_payment"].Value);
                        try
                        {
                            dr["reference_no"] = dgr.Cells["txt_gdv_ref_no"].Value.ToString();
                        }
                        catch
                        {
                            dr["reference_no"] = "";
                        }

                        payment_dt.Rows.Add(dr);
                    }
                }
                if (payment_dt.Rows.Count > 0)
                {
                    DateTime pay_date = dateTimePicker1.Value;
                    int check = obj_bal_vendor_payment_entry.setBulkPayment(payment_dt, Login._userid, pay_date);
                    if (check > 0)
                    {
                        lbl_alert.Text = "Payment Successfully Completed";
                        lbl_alert.Visible = true;
                        getGridviewData();
                    }
                    else
                    {
                        lbl_alert.Text = "Oops... Something went wrong! Please try again later";
                        lbl_alert.Visible = true;
                    }
                }
                else
                {
                    MessageBox.Show("Please enter an amount to pay!");
                }
            }
            catch (Exception)
            {
                lbl_alert.Text = "Oops... Something went wrong! Please try again later";
                lbl_alert.Visible = true;
            }
        }


    }
}
