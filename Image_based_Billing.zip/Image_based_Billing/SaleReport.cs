﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bal;
using entity;
using System.Diagnostics;


namespace Image_Based_Billing
{
    public partial class SaleReport : Form
    {
        public static long _saleid = 0;
        common obj_common = new common();
        Report obj_en_Report;
        bal_sale_report obj_bal_sale_report = new bal_sale_report();
        string _filepath = "";
        public SaleReport()
        {
            InitializeComponent();

            comboBox1.SelectedIndex = 0;
            mcc_customer.Clear();
            mcc_customer.SourceDataString = new string[4] { "cust_company", "cust_phone", "cust_address", "id" };
            mcc_customer.ColumnWidth = new string[4] { "300", "150", "500", "0" };
            mcc_customer.DataSource = new bal_customer().loadCustomer(Login._userid).Tables[0];
            mcc_customer.DisplayColumnNo = 0;
            mcc_customer.ValueColumnNo = 3;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {

            obj_en_Report = new Report();

            getGridviewData();
        }

        private void getGridviewData()
        {
            try
            {
                obj_en_Report.cust_id = Convert.ToInt64(mcc_customer.SelectedItem.Value);

            }
            catch (Exception)
            {
                obj_en_Report.cust_id = 0;
            }
            obj_en_Report.from_date = Convert.ToDateTime(dtp_from_date.Text);
            obj_en_Report.to_date = Convert.ToDateTime(dtp_to_date.Text);
            obj_en_Report.insert_user = Login._userid;
            DataSet ds = obj_bal_sale_report.getGridviewData(obj_en_Report);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gdv_report.AutoGenerateColumns = false;
                gdv_report.DataSource = ds.Tables[0];
                gdv_report.Columns["txt_gdv_sale_id"].DataPropertyName = "id";
                gdv_report.Columns["txt_gdv_cust_id"].DataPropertyName = "customer_id";
                gdv_report.Columns["txt_gdv_customer"].DataPropertyName = "cust_company";
                gdv_report.Columns["txt_gdv_cust_phone"].DataPropertyName = "cust_phone";
                gdv_report.Columns["txt_gdv_cust_address"].DataPropertyName = "cust_address";
                gdv_report.Columns["txt_gdv_sale_date"].DataPropertyName = "sale_time";
                gdv_report.Columns["txt_gdv_discount"].DataPropertyName = "total_discount";
                gdv_report.Columns["txt_gdv_total_amount"].DataPropertyName = "total_amount";
                gdv_report.Columns["txt_gdv_payable_amount"].DataPropertyName = "payable_amount";
                gdv_report.Columns["txt_gdv_payment"].DataPropertyName = "payment";
                gdv_report.Columns["txt_gdv_pending"].DataPropertyName = "pending";
                gdv_report.Columns["txt_gdv_due_date"].DataPropertyName = "due_date";
                btn_excel_export.Visible = true;
            }
            paintCells();
        }

        private void paintCells()
        {
            if (gdv_report.Rows.Count > 0)
            {
                try
                {
                    foreach (DataGridViewRow gdvr in gdv_report.Rows)
                    {
                        if (25000 <= Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value))
                        {
                            gdvr.Cells["txt_gdv_pending"].Style.BackColor = Color.Red;
                        }
                        if (10000 < Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value) && Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value) < 25000)
                        {
                            gdvr.Cells["txt_gdv_pending"].Style.BackColor = Color.Yellow;
                        }
                        if (5000 < Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value) && Convert.ToDecimal(gdvr.Cells["txt_gdv_pending"].Value) < 10000)
                        {
                            gdvr.Cells["txt_gdv_pending"].Style.BackColor = Color.GreenYellow;
                        }

                        if (gdvr.Cells["txt_gdv_due_date"].Value != DBNull.Value)
                        {
                            if (Convert.ToDateTime(gdvr.Cells["txt_gdv_due_date"].Value) <= DateTime.Now)
                            {
                                gdvr.Cells["txt_gdv_due_date"].Style.BackColor = Color.LightGray;
                            }
                        }
                    }
                }
                catch
                {


                }
            }


        }

        private void gdv_report_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            obj_common.gdvRowPostPaint(sender, e);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            mcc_customer.DisplayColumnNo = comboBox1.SelectedIndex;
        }

        private void btn_excel_export_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable sale_report_dt = getDataForExcel();
                Excel.ExcelUtlity obj_excel_util = new Excel.ExcelUtlity();
                _filepath = Application.StartupPath + "\\Files\\Reports\\Sale_" + DateTime.Now.ToString("dd-MMM-yyyy HH-mm") + ".xlsx";
                obj_excel_util.WriteDataTableToExcel(sale_report_dt, "Sale Report", _filepath, "");
                MessageBox.Show("Successfully Exported");
                Process obj_open = new Process();
                obj_open.StartInfo.FileName = _filepath;
                obj_open.Start();
            }
            catch
            {

            }
        }

        private DataTable getDataForExcel()
        {

            DataTable gridview_dt = new DataTable();
            gridview_dt.Columns.Add("Customer");
            gridview_dt.Columns.Add("Phone");
            gridview_dt.Columns.Add("Address");
            gridview_dt.Columns.Add("Sale_Date");
            gridview_dt.Columns.Add("Total_Amount");
            gridview_dt.Columns.Add("Discount_Amount");
            gridview_dt.Columns.Add("Payable_Amount");
            gridview_dt.Columns.Add("Payment_Received");
            gridview_dt.Columns.Add("Pending Amount");

            foreach (DataGridViewRow dr in gdv_report.Rows)
            {
                DataRow row = gridview_dt.NewRow();

                for (int i = 0; i < 8; i++)
                {
                    row[i] = dr.Cells[i + 2].Value.ToString();
                }
                gridview_dt.Rows.Add(row);
            }
            return gridview_dt;
        }

        private void gdv_report_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == gdv_report.Columns.IndexOf(gdv_report.Columns["btn_view"]))
            {
                DataGridView sender_gdv = (DataGridView)sender;
                DataGridViewRow gdvr = sender_gdv.Rows[e.RowIndex];
                _saleid = Convert.ToInt64(gdvr.Cells["txt_gdv_sale_id"].Value);
                SaleDetailDialog obj_dialog = new SaleDetailDialog();
                obj_dialog.ShowDialog();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dtp_to_date_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dtp_from_date_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void mcc_customer_Load(object sender, EventArgs e)
        {

        }


    }
}
