﻿namespace Image_Based_Billing
{
    partial class VendorPaymentEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_pay = new System.Windows.Forms.Button();
            this.dtp_to_date = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.dtp_from_date = new System.Windows.Forms.DateTimePicker();
            this.lbl_alert = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.mcc_vendor = new VMultiColumnComboBox.MultiColumComboBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.gdv_pendings = new System.Windows.Forms.DataGridView();
            this.txt_gdv_purchase_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_vend_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_vend_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_phone_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_purchase_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_final_payable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_pending = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_payment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_ref_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbl_header_id = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_pendings)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_pay
            // 
            this.btn_pay.Location = new System.Drawing.Point(1099, 206);
            this.btn_pay.Name = "btn_pay";
            this.btn_pay.Size = new System.Drawing.Size(75, 23);
            this.btn_pay.TabIndex = 5;
            this.btn_pay.Text = "Pay";
            this.btn_pay.UseVisualStyleBackColor = true;
            this.btn_pay.Click += new System.EventHandler(this.btn_pay_Click);
            // 
            // dtp_to_date
            // 
            this.dtp_to_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_to_date.Location = new System.Drawing.Point(764, 150);
            this.dtp_to_date.Name = "dtp_to_date";
            this.dtp_to_date.Size = new System.Drawing.Size(300, 26);
            this.dtp_to_date.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(643, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 20);
            this.label3.TabIndex = 170;
            this.label3.Text = "To";
            // 
            // dtp_from_date
            // 
            this.dtp_from_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_from_date.Location = new System.Drawing.Point(235, 149);
            this.dtp_from_date.Name = "dtp_from_date";
            this.dtp_from_date.Size = new System.Drawing.Size(300, 26);
            this.dtp_from_date.TabIndex = 1;
            this.dtp_from_date.Value = new System.DateTime(2017, 4, 1, 0, 0, 0, 0);
            // 
            // lbl_alert
            // 
            this.lbl_alert.AutoSize = true;
            this.lbl_alert.Location = new System.Drawing.Point(1096, 240);
            this.lbl_alert.Name = "lbl_alert";
            this.lbl_alert.Size = new System.Drawing.Size(0, 13);
            this.lbl_alert.TabIndex = 169;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(127, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 20);
            this.label2.TabIndex = 168;
            this.label2.Text = "Vendor";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Company Name",
            "Phone Number",
            "Address"});
            this.comboBox1.Location = new System.Drawing.Point(1073, 106);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(101, 21);
            this.comboBox1.TabIndex = 167;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // mcc_vendor
            // 
            this.mcc_vendor.ColumnWidth = null;
            this.mcc_vendor.DataSource = null;
            this.mcc_vendor.DisplayColumnNo = 1;
            this.mcc_vendor.DropDownHeight = 200;
            this.mcc_vendor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mcc_vendor.GridLines = VMultiColumnComboBox.GridLines.None;
            this.mcc_vendor.Location = new System.Drawing.Point(235, 105);
            this.mcc_vendor.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.mcc_vendor.Name = "mcc_vendor";
            this.mcc_vendor.SelectedItem = null;
            this.mcc_vendor.ShowHeader = false;
            this.mcc_vendor.Size = new System.Drawing.Size(829, 24);
            this.mcc_vendor.SourceDataHeader = null;
            this.mcc_vendor.SourceDataString = null;
            this.mcc_vendor.TabIndex = 0;
            this.mcc_vendor.ValueColumnNo = 0;
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(621, 196);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 33);
            this.btn_search.TabIndex = 3;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(127, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 20);
            this.label4.TabIndex = 171;
            this.label4.Text = "Sale Date";
            // 
            // gdv_pendings
            // 
            this.gdv_pendings.AllowUserToAddRows = false;
            this.gdv_pendings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdv_pendings.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gdv_pendings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_pendings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_purchase_id,
            this.txt_gdv_vend_id,
            this.txt_gdv_vend_name,
            this.txt_gdv_phone_no,
            this.txt_gdv_purchase_date,
            this.txt_gdv_final_payable,
            this.txt_gdv_pending,
            this.txt_gdv_payment,
            this.txt_gdv_ref_no});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gdv_pendings.DefaultCellStyle = dataGridViewCellStyle2;
            this.gdv_pendings.Location = new System.Drawing.Point(131, 273);
            this.gdv_pendings.Name = "gdv_pendings";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdv_pendings.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gdv_pendings.Size = new System.Drawing.Size(1043, 308);
            this.gdv_pendings.TabIndex = 4;
            this.gdv_pendings.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_pendings_CellEndEdit);
            this.gdv_pendings.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_pendings_RowPostPaint);
            // 
            // txt_gdv_purchase_id
            // 
            this.txt_gdv_purchase_id.HeaderText = "";
            this.txt_gdv_purchase_id.Name = "txt_gdv_purchase_id";
            this.txt_gdv_purchase_id.ReadOnly = true;
            this.txt_gdv_purchase_id.Visible = false;
            // 
            // txt_gdv_vend_id
            // 
            this.txt_gdv_vend_id.HeaderText = "";
            this.txt_gdv_vend_id.Name = "txt_gdv_vend_id";
            this.txt_gdv_vend_id.ReadOnly = true;
            this.txt_gdv_vend_id.Visible = false;
            // 
            // txt_gdv_vend_name
            // 
            this.txt_gdv_vend_name.HeaderText = "Vendor Name";
            this.txt_gdv_vend_name.Name = "txt_gdv_vend_name";
            this.txt_gdv_vend_name.ReadOnly = true;
            // 
            // txt_gdv_phone_no
            // 
            this.txt_gdv_phone_no.HeaderText = "Phone No.";
            this.txt_gdv_phone_no.Name = "txt_gdv_phone_no";
            this.txt_gdv_phone_no.ReadOnly = true;
            // 
            // txt_gdv_purchase_date
            // 
            this.txt_gdv_purchase_date.HeaderText = "Purchase Date";
            this.txt_gdv_purchase_date.Name = "txt_gdv_purchase_date";
            this.txt_gdv_purchase_date.ReadOnly = true;
            // 
            // txt_gdv_final_payable
            // 
            this.txt_gdv_final_payable.HeaderText = "Payable";
            this.txt_gdv_final_payable.Name = "txt_gdv_final_payable";
            this.txt_gdv_final_payable.ReadOnly = true;
            // 
            // txt_gdv_pending
            // 
            this.txt_gdv_pending.HeaderText = "Pending Amount";
            this.txt_gdv_pending.Name = "txt_gdv_pending";
            this.txt_gdv_pending.ReadOnly = true;
            // 
            // txt_gdv_payment
            // 
            this.txt_gdv_payment.HeaderText = "Payment";
            this.txt_gdv_payment.Name = "txt_gdv_payment";
            // 
            // txt_gdv_ref_no
            // 
            this.txt_gdv_ref_no.HeaderText = "Reference No.";
            this.txt_gdv_ref_no.Name = "txt_gdv_ref_no";
            // 
            // lbl_header_id
            // 
            this.lbl_header_id.AutoSize = true;
            this.lbl_header_id.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbl_header_id.Location = new System.Drawing.Point(83, 146);
            this.lbl_header_id.Name = "lbl_header_id";
            this.lbl_header_id.Size = new System.Drawing.Size(0, 13);
            this.lbl_header_id.TabIndex = 166;
            this.lbl_header_id.Visible = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(411, 46);
            this.label1.TabIndex = 164;
            this.label1.Text = "Vendor Payment Entry";
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(1, 71);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1308, 2);
            this.label10.TabIndex = 165;
            this.label10.Text = "  ";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(947, 36);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(226, 22);
            this.dateTimePicker1.TabIndex = 172;
            // 
            // VendorPaymentEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 721);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btn_pay);
            this.Controls.Add(this.dtp_to_date);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtp_from_date);
            this.Controls.Add(this.lbl_alert);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.mcc_vendor);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gdv_pendings);
            this.Controls.Add(this.lbl_header_id);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label10);
            this.Name = "VendorPaymentEntry";
            this.Text = "VendorPaymentEntry";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.gdv_pendings)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_pay;
        private System.Windows.Forms.DateTimePicker dtp_to_date;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtp_from_date;
        private System.Windows.Forms.Label lbl_alert;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private VMultiColumnComboBox.MultiColumComboBox mcc_vendor;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView gdv_pendings;
        private System.Windows.Forms.Label lbl_header_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_purchase_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_vend_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_vend_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_phone_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_purchase_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_final_payable;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_pending;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_payment;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_ref_no;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}