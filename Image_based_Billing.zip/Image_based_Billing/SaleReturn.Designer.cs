﻿namespace Image_Based_Billing
{
    partial class SaleReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_gdv_img_delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label13 = new System.Windows.Forms.Label();
            this.cmb_item_name = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txt_date = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_net_amt = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btn_image_add = new System.Windows.Forms.Button();
            this.txt_img_total = new System.Windows.Forms.TextBox();
            this.txt_item_quantity = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_browse = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_image = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_gdv_img_total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gdv_item = new System.Windows.Forms.DataGridView();
            this.txt_gdv_item_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_disc_percent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_disc_amt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_item_total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_gdv_item_delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_item_total = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_item_price = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.lbl_alert = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mcc_customer = new VMultiColumnComboBox.MultiColumComboBox();
            this.gdv_image = new System.Windows.Forms.DataGridView();
            this.txt_gdv_img_image = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_img_value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_img_disc_percent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_gdv_img_disc_amt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_item_add = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_item)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_image)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_gdv_img_delete
            // 
            this.btn_gdv_img_delete.HeaderText = "";
            this.btn_gdv_img_delete.Name = "btn_gdv_img_delete";
            this.btn_gdv_img_delete.Text = "Delete";
            this.btn_gdv_img_delete.UseColumnTextForButtonValue = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(942, 314);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 20);
            this.label13.TabIndex = 249;
            this.label13.Text = "Value";
            // 
            // cmb_item_name
            // 
            this.cmb_item_name.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmb_item_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_item_name.FormattingEnabled = true;
            this.cmb_item_name.Location = new System.Drawing.Point(68, 128);
            this.cmb_item_name.Name = "cmb_item_name";
            this.cmb_item_name.Size = new System.Drawing.Size(304, 24);
            this.cmb_item_name.TabIndex = 213;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Company Name",
            "Phone Number",
            "Address"});
            this.comboBox1.Location = new System.Drawing.Point(1178, 70);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(86, 21);
            this.comboBox1.TabIndex = 248;
            // 
            // txt_date
            // 
            this.txt_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_date.Location = new System.Drawing.Point(945, 8);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(184, 26);
            this.txt_date.TabIndex = 246;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(872, 11);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 20);
            this.label15.TabIndex = 247;
            this.label15.Text = "Date";
            // 
            // txt_net_amt
            // 
            this.txt_net_amt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_net_amt.Location = new System.Drawing.Point(876, 561);
            this.txt_net_amt.Name = "txt_net_amt";
            this.txt_net_amt.ReadOnly = true;
            this.txt_net_amt.Size = new System.Drawing.Size(180, 26);
            this.txt_net_amt.TabIndex = 242;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(872, 540);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 20);
            this.label17.TabIndex = 240;
            this.label17.Text = "Net Amount";
            // 
            // btn_image_add
            // 
            this.btn_image_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_image_add.Location = new System.Drawing.Point(1195, 332);
            this.btn_image_add.Name = "btn_image_add";
            this.btn_image_add.Size = new System.Drawing.Size(69, 31);
            this.btn_image_add.TabIndex = 221;
            this.btn_image_add.Text = "Add";
            this.btn_image_add.UseVisualStyleBackColor = true;
            this.btn_image_add.Click += new System.EventHandler(this.btn_image_add_Click);
            // 
            // txt_img_total
            // 
            this.txt_img_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_img_total.Location = new System.Drawing.Point(945, 337);
            this.txt_img_total.Name = "txt_img_total";
            this.txt_img_total.Size = new System.Drawing.Size(184, 26);
            this.txt_img_total.TabIndex = 219;
            this.txt_img_total.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_img_total_KeyPress);
            // 
            // txt_item_quantity
            // 
            this.txt_item_quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_item_quantity.Location = new System.Drawing.Point(680, 126);
            this.txt_item_quantity.Name = "txt_item_quantity";
            this.txt_item_quantity.Size = new System.Drawing.Size(193, 26);
            this.txt_item_quantity.TabIndex = 215;
            this.txt_item_quantity.TextChanged += new System.EventHandler(this.calcItemTotal);
            this.txt_item_quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_item_quantity_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(941, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 20);
            this.label3.TabIndex = 237;
            this.label3.Text = "Total";
            // 
            // btn_browse
            // 
            this.btn_browse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_browse.Location = new System.Drawing.Point(67, 337);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(110, 26);
            this.btn_browse.TabIndex = 218;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = true;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(259, 314);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 236;
            this.label6.Text = "Image";
            // 
            // txt_image
            // 
            this.txt_image.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_image.Location = new System.Drawing.Point(263, 337);
            this.txt_image.Name = "txt_image";
            this.txt_image.ReadOnly = true;
            this.txt_image.Size = new System.Drawing.Size(610, 26);
            this.txt_image.TabIndex = 220;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(64, 71);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 20);
            this.label11.TabIndex = 231;
            this.label11.Text = "Customer";
            // 
            // txt_gdv_img_total
            // 
            this.txt_gdv_img_total.HeaderText = "Total";
            this.txt_gdv_img_total.Name = "txt_gdv_img_total";
            this.txt_gdv_img_total.ReadOnly = true;
            // 
            // gdv_item
            // 
            this.gdv_item.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_item.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_item.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_item_id,
            this.txt_gdv_item_name,
            this.txt_gdv_item_price,
            this.txt_gdv_item_quantity,
            this.txt_gdv_item_disc_percent,
            this.txt_gdv_item_disc_amt,
            this.txt_gdv_item_total,
            this.btn_gdv_item_delete});
            this.gdv_item.Location = new System.Drawing.Point(68, 158);
            this.gdv_item.Name = "gdv_item";
            this.gdv_item.Size = new System.Drawing.Size(1196, 141);
            this.gdv_item.TabIndex = 217;
            this.gdv_item.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_item_CellContentClick);
            this.gdv_item.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_item_RowPostPaint);
            // 
            // txt_gdv_item_id
            // 
            this.txt_gdv_item_id.HeaderText = "";
            this.txt_gdv_item_id.Name = "txt_gdv_item_id";
            this.txt_gdv_item_id.Visible = false;
            // 
            // txt_gdv_item_name
            // 
            this.txt_gdv_item_name.HeaderText = "Item Name";
            this.txt_gdv_item_name.Name = "txt_gdv_item_name";
            this.txt_gdv_item_name.ReadOnly = true;
            // 
            // txt_gdv_item_price
            // 
            this.txt_gdv_item_price.HeaderText = "Price";
            this.txt_gdv_item_price.Name = "txt_gdv_item_price";
            this.txt_gdv_item_price.ReadOnly = true;
            // 
            // txt_gdv_item_quantity
            // 
            this.txt_gdv_item_quantity.HeaderText = "Quantity";
            this.txt_gdv_item_quantity.Name = "txt_gdv_item_quantity";
            this.txt_gdv_item_quantity.ReadOnly = true;
            // 
            // txt_gdv_item_disc_percent
            // 
            this.txt_gdv_item_disc_percent.HeaderText = "Discount %";
            this.txt_gdv_item_disc_percent.Name = "txt_gdv_item_disc_percent";
            this.txt_gdv_item_disc_percent.ReadOnly = true;
            this.txt_gdv_item_disc_percent.Visible = false;
            // 
            // txt_gdv_item_disc_amt
            // 
            this.txt_gdv_item_disc_amt.HeaderText = "Discount Amount";
            this.txt_gdv_item_disc_amt.Name = "txt_gdv_item_disc_amt";
            this.txt_gdv_item_disc_amt.ReadOnly = true;
            this.txt_gdv_item_disc_amt.Visible = false;
            // 
            // txt_gdv_item_total
            // 
            this.txt_gdv_item_total.HeaderText = "Total";
            this.txt_gdv_item_total.Name = "txt_gdv_item_total";
            this.txt_gdv_item_total.ReadOnly = true;
            // 
            // btn_gdv_item_delete
            // 
            this.btn_gdv_item_delete.HeaderText = "";
            this.btn_gdv_item_delete.Name = "btn_gdv_item_delete";
            this.btn_gdv_item_delete.ReadOnly = true;
            this.btn_gdv_item_delete.Text = "Delete";
            this.btn_gdv_item_delete.UseColumnTextForButtonValue = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(64, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 20);
            this.label5.TabIndex = 235;
            this.label5.Text = "Item Name";
            // 
            // txt_item_total
            // 
            this.txt_item_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_item_total.Location = new System.Drawing.Point(945, 126);
            this.txt_item_total.Name = "txt_item_total";
            this.txt_item_total.ReadOnly = true;
            this.txt_item_total.Size = new System.Drawing.Size(184, 26);
            this.txt_item_total.TabIndex = 234;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(676, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 233;
            this.label2.Text = "Quantity";
            // 
            // txt_item_price
            // 
            this.txt_item_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_item_price.Location = new System.Drawing.Point(423, 126);
            this.txt_item_price.Name = "txt_item_price";
            this.txt_item_price.Size = new System.Drawing.Size(189, 26);
            this.txt_item_price.TabIndex = 214;
            this.txt_item_price.TextChanged += new System.EventHandler(this.calcItemTotal);
            this.txt_item_price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_item_price_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(419, 105);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 20);
            this.label16.TabIndex = 232;
            this.label16.Text = "Price";
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(1195, 559);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(69, 31);
            this.btn_reset.TabIndex = 227;
            this.btn_reset.Text = "Clear";
            this.btn_reset.UseVisualStyleBackColor = true;
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(1106, 559);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(69, 31);
            this.btn_save.TabIndex = 226;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // lbl_alert
            // 
            this.lbl_alert.AutoSize = true;
            this.lbl_alert.Location = new System.Drawing.Point(540, 18);
            this.lbl_alert.Name = "lbl_alert";
            this.lbl_alert.Size = new System.Drawing.Size(0, 13);
            this.lbl_alert.TabIndex = 230;
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(-14, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1368, 2);
            this.label10.TabIndex = 229;
            this.label10.Text = "  ";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 42);
            this.label1.TabIndex = 228;
            this.label1.Text = "Sale Return Entry";
            // 
            // mcc_customer
            // 
            this.mcc_customer.ColumnWidth = null;
            this.mcc_customer.DataSource = null;
            this.mcc_customer.DisplayColumnNo = 1;
            this.mcc_customer.DropDownHeight = 200;
            this.mcc_customer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mcc_customer.GridLines = VMultiColumnComboBox.GridLines.None;
            this.mcc_customer.Location = new System.Drawing.Point(162, 67);
            this.mcc_customer.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.mcc_customer.Name = "mcc_customer";
            this.mcc_customer.SelectedItem = null;
            this.mcc_customer.ShowHeader = false;
            this.mcc_customer.Size = new System.Drawing.Size(958, 24);
            this.mcc_customer.SourceDataHeader = null;
            this.mcc_customer.SourceDataString = null;
            this.mcc_customer.TabIndex = 212;
            this.mcc_customer.ValueColumnNo = 0;
            // 
            // gdv_image
            // 
            this.gdv_image.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gdv_image.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_image.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txt_gdv_img_image,
            this.txt_gdv_img_value,
            this.txt_gdv_img_disc_percent,
            this.txt_gdv_img_disc_amt,
            this.txt_gdv_img_total,
            this.btn_gdv_img_delete});
            this.gdv_image.Location = new System.Drawing.Point(68, 369);
            this.gdv_image.Name = "gdv_image";
            this.gdv_image.Size = new System.Drawing.Size(1196, 153);
            this.gdv_image.TabIndex = 222;
            this.gdv_image.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdv_image_CellContentClick);
            this.gdv_image.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.gdv_image_RowPostPaint);
            // 
            // txt_gdv_img_image
            // 
            this.txt_gdv_img_image.HeaderText = "Image";
            this.txt_gdv_img_image.Name = "txt_gdv_img_image";
            this.txt_gdv_img_image.ReadOnly = true;
            // 
            // txt_gdv_img_value
            // 
            this.txt_gdv_img_value.HeaderText = "Value";
            this.txt_gdv_img_value.Name = "txt_gdv_img_value";
            this.txt_gdv_img_value.ReadOnly = true;
            this.txt_gdv_img_value.Visible = false;
            // 
            // txt_gdv_img_disc_percent
            // 
            this.txt_gdv_img_disc_percent.HeaderText = "Discount %";
            this.txt_gdv_img_disc_percent.Name = "txt_gdv_img_disc_percent";
            this.txt_gdv_img_disc_percent.ReadOnly = true;
            this.txt_gdv_img_disc_percent.Visible = false;
            // 
            // txt_gdv_img_disc_amt
            // 
            this.txt_gdv_img_disc_amt.HeaderText = "Discount Amount";
            this.txt_gdv_img_disc_amt.Name = "txt_gdv_img_disc_amt";
            this.txt_gdv_img_disc_amt.ReadOnly = true;
            this.txt_gdv_img_disc_amt.Visible = false;
            // 
            // btn_item_add
            // 
            this.btn_item_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_item_add.Location = new System.Drawing.Point(1195, 121);
            this.btn_item_add.Name = "btn_item_add";
            this.btn_item_add.Size = new System.Drawing.Size(69, 31);
            this.btn_item_add.TabIndex = 216;
            this.btn_item_add.Text = "Add";
            this.btn_item_add.UseVisualStyleBackColor = true;
            this.btn_item_add.Click += new System.EventHandler(this.btn_item_add_Click);
            // 
            // SaleReturn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 721);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cmb_item_name);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txt_net_amt);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.btn_image_add);
            this.Controls.Add(this.txt_img_total);
            this.Controls.Add(this.txt_item_quantity);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_browse);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_image);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.gdv_item);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_item_total);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_item_price);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.lbl_alert);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mcc_customer);
            this.Controls.Add(this.gdv_image);
            this.Controls.Add(this.btn_item_add);
            this.Name = "SaleReturn";
            this.Text = "SaleReturn";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.gdv_item)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_image)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewButtonColumn btn_gdv_img_delete;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmb_item_name;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DateTimePicker txt_date;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_net_amt;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btn_image_add;
        private System.Windows.Forms.TextBox txt_img_total;
        private System.Windows.Forms.TextBox txt_item_quantity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_image;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_total;
        private System.Windows.Forms.DataGridView gdv_item;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_price;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_disc_percent;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_disc_amt;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_item_total;
        private System.Windows.Forms.DataGridViewButtonColumn btn_gdv_item_delete;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_item_total;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_item_price;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label lbl_alert;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private VMultiColumnComboBox.MultiColumComboBox mcc_customer;
        private System.Windows.Forms.DataGridView gdv_image;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_image;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_value;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_disc_percent;
        private System.Windows.Forms.DataGridViewTextBoxColumn txt_gdv_img_disc_amt;
        private System.Windows.Forms.Button btn_item_add;
    }
}