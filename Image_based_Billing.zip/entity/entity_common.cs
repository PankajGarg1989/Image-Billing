﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entity
{
    public class Report : entity_sale
    {
        public long to_job_no { get; set; }
        public long from_job_no { get; set; }

        public DateTime from_date { get; set; }
        public DateTime to_date { get; set; }

        public long cust_id { get; set; }
        public long vend_id { get; set; }
        public string date_type { get; set; }

        
    }


    public class entity_comp_info : tbl_comp_info
    {

    }

    public class entity_login : tbl_login
    {

    }

    public class entity_m_customer : tbl_m_customer
    {

    }

    public class entity_m_items : tbl_m_items
    {

    }

    public class entity_m_pay_mode : tbl_m_pay_mode
    {

    }
    public class entity_m_session : tbl_m_session
    {

    }
    public class entity_m_tax : tbl_m_tax
    {


    }
    public class entity_m_vendor : tbl_m_vendor
    {

    }
    public class entity_payments : tbl_payments
    {

    }
    public class entity_purchase : tbl_purchase
    {

    }
    public class entity_purchase_detail : tbl_purchase_detail
    {

    }
    public class entity_purchase_files: tbl_purchase_files
    {

    }
    public class entity_sale : tbl_sale
    {

    }
    public class entity_sale_detail : tbl_sale_detail
    {

    }
    public class entity_sale_files : tbl_sale_files
    {

    }

    public class entity_sale_return : tbl_sale
    {

    }
   
}
