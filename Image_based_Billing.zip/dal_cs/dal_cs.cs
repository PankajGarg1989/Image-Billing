﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace dal_common
{
    public class dal
    {
        SqlConnection con;
        SqlCommand com;

        public int set(SqlParameter[] p, string store_procedure)
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            com = new SqlCommand(store_procedure, con);
            com.CommandType = CommandType.StoredProcedure;
            for (int count = 0; count < p.Length; count++)
            {
                com.Parameters.Add(p[count]);
            }
            con.Open();
            int check = com.ExecuteNonQuery();
            if (check > 0)
            {
                con.Close();
            }

            return check;
        }
        public DataSet get(SqlParameter[] p, string store_procedure)
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            com = new SqlCommand(store_procedure, con);
            SqlDataAdapter da = new SqlDataAdapter(com);

            da.SelectCommand.CommandType = CommandType.StoredProcedure;

            for (int count = 0; count < p.Length; count++)
            {

                da.SelectCommand.Parameters.Add(p[count]);
            }
            DataSet ds = new DataSet();
            da.Fill(ds);

            return ds;

        }
        public DataSet get(string store_procedure)
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            com = new SqlCommand(store_procedure, con);
            SqlDataAdapter da = new SqlDataAdapter(com);

            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataSet ds = new DataSet();
            da.Fill(ds);

            return ds;

        }


    }
}
